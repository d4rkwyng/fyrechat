Thank you for downloading FyreChat 2.1.09!


Please refer to the documents in the "docs" folder to assist you.

You may also find help at fyrechat.openfyre.net.

You must have Visual Basic Runtime Files to run this program and
have C++ Runtime Files to run the plugins.




If you have any questions, suggestions or bug reports, please send them
to fyre@openfyre.net


8/24/12