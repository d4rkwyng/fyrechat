Build 83
This version is unable to currently use two new features:
/versionout <user>
and
Re-write of /version, /about

When it is completed it will output the executable creation date and time.

A new feature is that you can now use an entirely different program to upload channel_list.txt to your domain.

http://www.efyre.com/fyre/?p=other
WebListUploader will upload the file for you.  You can use HideMSN to hide the window if you wish.
Remember to click Write Only in the WebList Form of FyreChat.
