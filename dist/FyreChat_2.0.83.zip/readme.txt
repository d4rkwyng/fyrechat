Thank you for downloading FyreChat!
Please refer to the Help file in the docs folder.

For further help:
http://www.efyre.com/fyre/?p=fyrechat