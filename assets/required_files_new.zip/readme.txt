Place the files ending in .ocx and .dll into your C:\Windows\System32
or C:\Windows\SysWOW64 (64-bit windows) directory on your computer.
Do not overwrite any files.

You many also run the COPY32.bat or COPY64.bat based on whether
you are running 32-bit or 64-bit Windows.

If you run into any errors loading FyreChat with an OCX file.  You
will need to manually register the OCX file with your system.

You can do this by opening command prompt, (xp: start -> run -> type cmd, hit enter)
(7: start -> type cmd, right-click, click run as administrator, accept UAC prompt)
To register the OCX/DLL, navigate to the appropriate folder for your system.  As
mentioned in the first paragraph.

type: cd C:\Windows\System32
or: cd C:\Windows\SysWow64

Then type: regsvr32 NAMEOFFILEHERE
(ex: regsvr32 MSWINSCK.oCX)