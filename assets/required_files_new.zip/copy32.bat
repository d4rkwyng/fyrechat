@echo off
title Copying DLLs and OCXs
SET SUBDIR=%~dp0
cd %SUBDIR%
xcopy *.OCX C:\Windows\System32 /F /R /Y /C
xcopy *.DLL C:\Windows\System32 /F /R /Y /C
cd C:\Windows\System32
regsvr32 /u /s tabctl32.ocx
regsvr32 /s tabctl32.ocx
regsvr32 /u /s mswinsck.ocx
regsvr32 /s mswinsck.ocx
regsvr32 /u /s richtx32.ocx
regsvr32 /s richtx32.ocx
echo Complete
pause