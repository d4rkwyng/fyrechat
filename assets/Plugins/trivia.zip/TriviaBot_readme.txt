TriviaBot by Spht
=================

First of all, this is not a bot--it's a plugin.  Specifically, a "BinaryChat plugin."  It's a binary application that adds a fully-functional trivia client to any "bot" that supports running BinaryChat plugins, such as SphtBotv3.  Theoretically, this plugin can be used on Battle.net, IRC, or any other chat medium the bot supports.

SphtBotv3, a Battle.net binary bot, can be downloaded here: http://www.valhallalegends.com/spht/sphtbotv3/


Getting started:
----------------

- To active the trivia, type /trivia on.  To put trivia in auto-on/off mode, type /trivia auto.  In this mode, trivia will activate when someone says "trivia" and it will turn off when no one is playing.

- To reset scores, simply delete the triviausers.txt file.


Features:
---------

- Points are awarded based on how fast question was answered as well as amount of active players in channel (active player is someone who's answered question in past 10 minutes).

- Additional point is given if player has made streak of 5 or more. Streak is interrupted by someone else answering, or time out.

- Assigns rank to every player in the database, and the bot's profile will always show the top 10 leading players.

- After answering your first question, you gain access to remote bot commands .score (user) and .rank (#) (can only be used in 20 second increments per player).

- Bot announces the player(s) ranked #1 every 4 hours.

- Players can use the .skip command to vote to skip the current question.  Questions can only be skipped by vote once every 10 minutes.  Skipping a question can be useful for maintaining your streak.

- Hints always reveal characters that are not a-z or 0-9, and those characters are ignored when accepting answers (so sarahspajamas?!! is an accepted answer for Sarah's Pajamas).


History:
--------

After spending some time playing trivia in various trivia channels, I noticed several things, whether it be channel conduct or technical set up, that I disliked about the channels I played in:

1) Channel moderation -- This can be good or bad.  Good if you have a few trusted people that can protect the channel from spammers and the like.  Bad if you have no guidelines and some of your moderators are starting arguments, banning to be "funny," banning casual players over something minor, or other "personal" reasons.  I've personally been banned from a channel just because I disagreed with one of the moderator's opinions (coincidentally, the moderator was rank 1 and I was quickly gaining on him).  Ironically, I've also been banned for NOT talking (apparently only answer bots don't respond when spoken to).  The only people that should be banned are those that deliberately come to the channel to disrupt.  If someone is playing trivia, and happens to have a nasty personality, why ruin their fun?  Battle.net has a great command called /ignore.

2) Uptime -- I swear, 50% of the time I would get on, at least one of the channels would be down.  Sometimes all of them!  This was the inspiration for the name of my channel, "Op Trivia247," a channel that you could guarantee would always be available.  Over the past few months, I believe I did a good job of that.

3) Technical flaws -- Sometimes your answer has to match the actual answer exactly to be correct (including spaces and punctuation).  Sometimes certain punctuation has to be used whereas others don't.  Sometimes the bot will ask questions that can't be read on StarCraft.  Sometimes the question is so long that it gets cut off.  Sometimes the answer is actually multiple alternative answers (like "george george bush george w bush"), which seems highly redundant.  Sometimes ranks overlap or bot doesn't understand ties.  Often times, it's unclear what position you rank at in comparison to all the other players.  That's all I can think of off hand.  I addressed all these issues and more in TriviaBot.

4) Abuse -- The trivia bots are prone to abuse.  Whether it be spamming 'score' queries to flood the bot or answer bots that overwhelm it.  In many cases it would make the bot unresponsive, IP banned from Battle.net, or just crash entirely.

5) Lack of players -- Trivia is a great game, but a lot of the time there weren't many people to play with.  Why not?  Who doesn't like trivia!  I concluded that it was likely due to all the issues I mentioned above, so I decided to create a channel that addressed all these issues.  If you build it, they will come.  This proved to be very true, as the channel received on average over 800 unique players per month, through word-of-mouth!


Conclusion:
-----------

I no longer host Op Trivia247.  I decided to release this plugin so that people can start up their own trivia channels or improve on existing ones.

This is the same plugin that was used for trivia in Op Trivia247, which for over a period of 4 months, was the most popular trivia channel on Battle.net (as judged by amount of monthly players and average channel volume).

Included is a small sample of questions to get you started (about 1% of what I used in Op Trivia247).

Enjoy!

Spht of Valhalla Legends

spht.vl@gmail.com

http://clangnome.spht.net/

http://forum.valhallalegends.com/
