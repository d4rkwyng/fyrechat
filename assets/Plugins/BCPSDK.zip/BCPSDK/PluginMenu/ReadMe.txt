PluginMenu Library Documentation
================================

Summary
=======

The PluginMenu library is designed to make it easy to use a common "Plugins"
menu for multiple plugins using the BCP standard.

In-depth Documentation
======================

The source files can be added into your project, or you can use the .lib
(included is a VC7-compatible version).  The "public" functions are documented
in PluginMenu.h.  You should keep the main Plugins menu name "&Plugins", as the
library is designed to work with multiple plugins adding and removing their own
submenu items in the Plugins menu.

To receive notification about menu item activation, you should install a message
hook on the parent bot's main window (as returned by PUIGetWindow).  Watch for
WM_COMMAND messages sent for menu items, and with the command id assigned to your
menu item(s) by the library.  I strongly recommend against subclassing the bot
windows, as this can cause the bot to crash if plugins are not unloaded in the
exact reverse order as they were loaded.  Using window hooks (see SetWindowsHookEx
and UnsetWindowsHookEx in the MSDN Platform SDK) eliminates this problem.

Remeber to remove menu items when your plugin is unloaded, or you'll leak resources,
not to mention leaving defunct menu items which probably won't make your users happy.

- Skywing