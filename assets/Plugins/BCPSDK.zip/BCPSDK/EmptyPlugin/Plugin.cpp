#include "Plugin.h"

// Message hook
#if MESSAGEHOOK_ENABLED
	BOOL Plugin::MessageHook(PluginAPI::ConnectionInterface Connection,
							 BYTE MessageId, LPCVOID MessageData, DWORD MessageSize)
	{
		// Add code here
		return FALSE;
	}
#endif

// Connection hook
#if CONNECTIONHOOK_ENABLED
	BOOL Plugin::ConnectionHook(PluginAPI::ConnectionInterface Connection,
								PluginAPI::ConnectionState EventCode, DWORDLONG PlatformId)
	{
		// Add code here
		return FALSE;
	}
#endif

// Plugin timer
#if PLUGINTIMER_ENABLED
	DWORD Plugin::PluginTimer(DWORD TimeDelay)
	{
		// Add code here
		return TimeDelay;
	}
#endif

// Command hook
#if COMMANDHOOK_ENABLED
	BOOL Plugin::CommandHook(LPCSTR Message, LPCSTR SendingUser, BOOL FromTelnet)
	{
		// Add code here
		return FALSE;
	}
#endif

// Event hook
#if EVENTHOOK_ENABLED
	BOOL Plugin::EventHook()
	{
		// Add code here
		return FALSE;
	}
#endif

// Enum channel callback
BOOL Plugin::EnumChannelHook(LPCSTR UniqueName, LPCSTR Statstring, DWORD Flags, DWORD Ping,
							 BOOL Invisible, DWORD AccountNumber, DWORD RegAuthority)
{
	// Add code here
	return TRUE;
}

#if HIGHEST_REVISION >= 4
	// Enum filter callbacks
	BOOL Plugin::EnumUserFiltersHook(LPCSTR Filter)
	{
		// Add code here
		return TRUE;
	}

	BOOL Plugin::EnumMessageFiltersHook(LPCSTR Filter)
	{
		// Add code here
		return TRUE;
	}

	// Enum plugins callback
	BOOL Plugin::EnumLoadedPluginsHook(HINSTANCE PluginInst)
	{
		// Add code here
		return TRUE;
	}
#endif

BOOL Plugin::Initialize()
{
	// Initialization code here
	return TRUE;
}

void Plugin::Terminate()
{
	// Termination code here
}