#include "Plugin.h"

BOOL WINAPI BinaryChatAPIManager::EnumChannelHook(LPCSTR UniqueName, LPCSTR Statstring,
												  DWORD Flags, DWORD Ping, BOOL Invisible,
												  DWORD AccountNumber, DWORD RegAuthority,
												  LPARAM lParam)
{
	return reinterpret_cast<HookManager*>(lParam)->EnumChannelHook(UniqueName, Statstring,
		Flags, Ping, Invisible, AccountNumber, RegAuthority);
}

#if HIGHEST_REVISION >= 4
	BOOL WINAPI BinaryChatAPIManager::EnumUserFiltersHook(LPCSTR Filter, LPARAM lParam)
	{
		return reinterpret_cast<HookManager*>(lParam)->EnumUserFiltersHook(Filter);
	}

	BOOL WINAPI BinaryChatAPIManager::EnumMessageFiltersHook(LPCSTR Filter, LPARAM lParam)
	{
		return reinterpret_cast<HookManager*>(lParam)->EnumMessageFiltersHook(Filter);
	}

	BOOL WINAPI BinaryChatAPIManager::EnumLoadedPluginsHook(HINSTANCE PluginInst, LPARAM lParam)
	{
		return reinterpret_cast<HookManager*>(lParam)->EnumLoadedPluginsHook(PluginInst);
	}
#endif