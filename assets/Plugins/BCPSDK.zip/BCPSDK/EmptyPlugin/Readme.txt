EmptyPlugin Tiny Readme
=======================

Files to modify: PluginSettings.h, Plugin.cpp
(Add more files as necessary)
Make sure a hook is enabled (set to TRUE in PluginSettings.h) or it won't be compiled.
Use the "API" object to access BinaryChat functions (such as WriteOutputString): API.WriteOutputString("Hi\n");

-Yoni