Attribute VB_Name = "modFeatureFunctions"
 Global Const NIM_ADD = &H0
 Global Const NIM_MODIFY = &H1
 Global Const NIM_DELETE = &H2
 Global Const WM_MOUSEMOVE = &H200
 Global Const NIF_MESSAGE = &H1
 Global Const NIF_ICON = &H2
 Global Const NIF_TIP = &H4
 Global Const WM_LBUTTONDBLCLK = &H203
 Global Const WM_LBUTTONDOWN = &H201
 Global Const WM_LBUTTONUP = &H202
 Global Const WM_RBUTTONDBLCLK = &H206
 Global Const WM_RBUTTONDOWN = &H204
 Global Const WM_RBUTTONUP = &H205
Public Function FormatCount(Count As Long, Optional FormatType As TimeFormatType = 4) As String
    Dim Days As Long, Hours As Long, Minutes As Long, Seconds As Long, Miliseconds As Long
    Miliseconds = Count Mod 1000
    Count = Count \ 1000
    Days = Count \ (24& * 3600&)
    If Days > 0 Then Count = Count - (24& * 3600& * Days)
    Hours = Count \ 3600&
    If Hours > 0 Then Count = Count - (3600& * Hours)
    Minutes = Count \ 60
    Seconds = Count Mod 60
    Select Case FormatType
        Case 0
            FormatCount = Days & " days, " & Hours & " hours, " & _
            Minutes & " minutes, " & Seconds & " seconds, " & Miliseconds & _
            " milliseconds"
        Case 1
            FormatCount = Days & " days, " & Hours & " hours, " & _
            Minutes & " minutes, " & Seconds & " seconds"
        Case 2
            FormatCount = Days & ":" & Hours & ":" & _
            Minutes & ":" & Seconds & ":" & Miliseconds
        Case 3
            Select Case Minutes
                Case "0"
                Case "1"
                    FormatCount = Minutes & " minute"
                Case Else
                    FormatCount = Minutes & " minutes"
            End Select
            Select Case Hours
                Case "0"
                Case "1"
                    FormatCount = Hours & " hour and " & Minutes & " minutes"
                Case Else
                    FormatCount = Hours & " hours and " & Minutes & " minutes"
            End Select
            Select Case Days
                Case "0"
                Case "1"
                    FormatCount = Days & " day, " & Hours & " hours and " & Minutes & " minutes"
                Case Else
                    FormatCount = Days & " days, " & Hours & " hours and " & Minutes & " minutes"
            End Select
        Case 4
            Select Case Seconds
                Case "0"
                    FormatCount = "birth"
                Case Else
                    FormatCount = Seconds & " seconds"
            End Select
            Select Case Minutes
                Case "0"
                Case "1"
                    FormatCount = Minutes & " minute, " & Seconds & " seconds"
                Case Else
                    FormatCount = Minutes & " minutes, " & Seconds & " seconds"
            End Select
            Select Case Hours
                Case "0"
                Case "1"
                    FormatCount = Hours & " hour, " & Minutes & " minutes, " & Seconds & " seconds"
                Case Else
                    FormatCount = Hours & " hours, " & Minutes & " minutes, " & Seconds & " seconds"
            End Select
            Select Case Days
                Case "0"
                Case "1"
                    FormatCount = Days & " day, " & Hours & " hours, " & Minutes & " minutes, " & Seconds & " seconds"
                Case Else
                    FormatCount = Days & " days, " & Hours & " hours, " & Minutes & " minutes, " & Seconds & " seconds"
            End Select
        End Select
End Function
Public Sub RequestProfile(strUser As String, game As String)
    Dim lngKey As Long
    lngKey = GetTickCount()
    varRequestType = "Profile"
    With PBuffer
        .InsertDWORD 1
        .InsertDWORD 18
        .InsertDWORD lngKey
        .InsertNTString strUser
        .InsertNTString "profile\sex"
        .InsertNTString "profile\age"
        .InsertNTString "profile\location"
        .InsertNTString "profile\description"
        .InsertNTString "Record\" & game & "\0\wins"
        .InsertNTString "Record\" & game & "\0\losses"
        .InsertNTString "Record\" & game & "\0\disconnects"
        .InsertNTString "Record\" & game & "\0\last game"
        .InsertNTString "Record\" & game & "\0\last game result"
        .InsertNTString "Record\" & game & "\1\wins"
        .InsertNTString "Record\" & game & "\1\losses"
        .InsertNTString "Record\" & game & "\1\disconnects"
        .InsertNTString "Record\" & game & "\1\last game"
        .InsertNTString "Record\" & game & "\1\last game result"
        .InsertNTString "Record\" & game & "\1\rating"
        .InsertNTString "Record\" & game & "\1\high rating"
        .InsertNTString "Record\" & game & "\1\rank"
        .InsertNTString "Record\" & game & "\1\high rank"
        .SendPacket &H26
    End With
End Sub
Public Function RequestRecordData(strUser As String)
    Dim lngKey As Long
    lngKey = GetTickCount()
    varRequestType = "RecordData"

    With PBuffer
        .InsertDWORD 1
        .InsertDWORD 6
        .InsertDWORD lngKey
        .InsertNTString strUser
        .InsertNTString "System\Account Created"
        .InsertNTString "System\Username"
        .InsertNTString "System\Last Logon"
        .InsertNTString "System\Account Expires"
        .InsertNTString "System\Last Logoff"
        .InsertNTString "System\Time Logged"
        .SendPacket &H26
    End With
End Function
Public Function GetDWORD(Data As String) As Long
Dim lReturn As Long
    Call CopyMemory(lReturn, ByVal Data, 4)
    GetDWORD = lReturn
End Function
Public Function CreateChar(Class As String, expansion As String, hardcore As String, Name As String)
If BNET.Product = "PX2D" Then expansion = "1"
With PBuffer
    .InsertDWORD "&H" & charclass(Class)
    .InsertWORD "&H" & CharMask(expansion, hardcore)
    .InsertNTString Name
    .SendRPacket &H2
End With
End Function
Public Function charclass(Class As String) As String
    If Class = "Amazon" Then
        charclass = "00"
    ElseIf Class = "Sorceress" Then
        charclass = "01"
    ElseIf Class = "Necromancer" Then
        charclass = "02"
    ElseIf Class = "Paladin" Then
        charclass = "03"
    ElseIf Class = "Barbarian" Then
        charclass = "04"
    ElseIf Class = "Druid" Then
        charclass = "05"
    ElseIf Class = "Assassin" Then
        charclass = "06"
    Else
        charclass = "00"
    End If
End Function
Public Function CharMask(exp As String, hc As String) As String
    If (exp = "1") And (hc = "1") Then
        CharMask = "24"
    ElseIf (exp = "1") And (hc = "0") Then
        CharMask = "20"
    ElseIf (exp = "0") And (hc = "1") Then
        CharMask = "04"
    ElseIf (exp = "0") And (hc = "0") Then
        CharMask = "00"
    Else
        CharMask = "24"
    End If
End Function
Public Function ConnectMCP(Realm As String)
    Dim rpass As String
    rpass = String(5 * 4, vbNullChar)
        Call A2(rpass, Servers)
        With PBuffer
            .InsertDWORD &H1
            .InsertNonNTString rpass
            .InsertNTString Realm
            .SendPacket &H3E
        End With
End Function
Public Function LogonRealmChar(charname As String)
    With PBuffer
        .InsertNTString charname
        .SendRPacket &H7
    End With
End Function
Public Function DeleteChar(character As String)
With PBuffer
    .InsertWORD &H0
    .InsertNTString character
    .SendRPacket &HA
    AddChat vbD2Grey, "Character " & character & " deleted."
End With
End Function
'Credit to RHiNo for the System Tray Code
'Edited by FyRe, as known on battle.net (webmaster@efyre.com)
Sub AddToTray(TrayIcon, TrayText As String, TrayForm As Form)
    nid.cbSize = Len(nid)
    nid.HWnd = TrayForm.HWnd
    nid.uId = vbNull
    nid.uFlags = NIF_ICON Or NIF_TIP Or NIF_MESSAGE
    nid.uCallBackMessage = WM_MOUSEMOVE
    nid.hIcon = TrayIcon
    nid.szTip = TrayText & vbNullChar
    Shell_NotifyIcon NIM_ADD, nid
End Sub
Sub ModifyTray(TrayIcon, TrayText As String, TrayForm As Form)
    nid.cbSize = Len(nid)
    nid.HWnd = TrayForm.HWnd
    nid.uId = vbNull
    nid.uFlags = NIF_ICON Or NIF_TIP Or NIF_MESSAGE
    nid.uCallBackMessage = WM_MOUSEMOVE
    nid.hIcon = TrayIcon
    nid.szTip = TrayText & vbNullChar
    Shell_NotifyIcon NIM_MODIFY, nid
End Sub
Sub RemoveFromTray()
    Shell_NotifyIcon NIM_DELETE, nid
End Sub
Function RespondToTray(X As Single)
    Dim AcessMenuTray As Boolean
    RespondToTray = 0
    Dim msg As Long
    Dim sFilter As String
    If frmMain.ScaleMode <> 3 Then msg = X / Screen.TwipsPerPixelX Else: msg = X
    Select Case msg
        Case WM_LBUTTONDOWN
        Case WM_LBUTTONUP
        Case WM_LBUTTONDBLCLK
        RespondToTray = 1
    End Select
End Function
Sub ShowFormAgain(TrayForm As Form)
    If vbMax Then
        frmMain.WindowState = 2
    Else
        frmMain.WindowState = 0
    End If
    frmMain.Show
 End Sub
' Credit to Grok[vL] for his DebugOutput Function
'Edited by FyRe, as known on battle.net (webmaster@efyre.com)
Public Function DebugOutput(ByVal sIn As String) As String
    Dim x1 As Long, y1 As Long
    Dim iLen As Long, iPos As Long
    Dim sB As String, sT As String
    Dim sOut As String
    Dim Offset As Long, sOffset As String

    '//Below is a test sample
    'y1 = 256
    'sIn = String(y1, 0)
    'For x1 = 1 To 256
    'Mid(sIn, x1, 1) = Chr(x1 - 1)
    'Mid(sIn, x1, 1) = Chr(255 * Rnd())
    'Next x1
    '//End

    iLen = Len(sIn)
    If iLen = 0 Then Exit Function
    sOut = ""
    Offset = 0
    For x1 = 0 To ((iLen - 1) \ 16)
        sOffset = Right$("0000" & Hex(Offset), 4)
        sB = String(48, " ")
        sT = "................"
    For y1 = 1 To 16
        iPos = 16 * x1 + y1
    If iPos > iLen Then Exit For
    Mid(sB, 3 * (y1 - 1) + 1, 2) = Right("00" & Hex(Asc(Mid(sIn, iPos, 1))), 2) & " "
    Select Case Asc(Mid(sIn, iPos, 1))
        Case 0, 9, 10, 13
        Case Else
            Mid(sT, y1, 1) = Mid(sIn, iPos, 1)
    End Select
    Next y1
    If Len(sOut) > 0 Then sOut = sOut & vbCrLf
    sOut = sOut & sOffset & ": "
    sOut = sOut & sB & " " & sT
    Offset = Offset + 16
    Next x1
    DebugOutput = sOut
    '/debug feature
    AddChat vbRed, "Debugged: ", vbWhite, DebugOutput
End Function
'DM's Encryption Code, Edited by WoLF`FaLLeN
Public Function Encrypt(eStr As String) As String
    Dim i As Integer, tmp As Integer
    Randomize
    Encrypt = ""
    If Len(eStr) > 110 Then eStr = Mid(eStr, 1, 110)
    Encrypt = Chr(Len(eStr) + 64)
    For i = 1 To Len(eStr)
    tmp = Int(20 * Rnd) + 1
    Encrypt = Encrypt & Chr(tmp + 234) & Chr((Asc(Mid(eStr, i, 1)) Xor tmp) + 63)
    Next i
    While Len(Encrypt) < 221
        Encrypt = Encrypt & Chr(Int(180 * Rnd) + 60)
    Wend
End Function
Public Function Decrypt(eStr As String) As String
    Dim i As Integer, key As Byte
    For i = 2 To 2 * (Asc(Left$(eStr, 1)) - 64) Step 2
        key = (Asc(Mid$(eStr, i, 1))) - 234
        Decrypt = Decrypt & Chr((Asc(Mid$(eStr, i + 1)) - 63) Xor key)
    Next i
End Function
Public Function hexEncrypt(ByVal sString As String) As String
    Dim sHex As String
    Dim i As Long
    Dim pos As Long
    Dim Encrypt As Boolean
    Dim sNew As String
    Dim sTmp As String
    Dim iDec As Long
    pos = 1
    For i = 1 To Len(sString)
    If Mid(sString, 1, 1) <> Chr(163) Then
        sHex = sHex & Hex$(Asc(Mid(sString, i, 1)))
        If Len(sHex) = 1 Then sHex = "0" & sHex
            Encrypt = True
        Else
            sTmp = Mid(sString, 2, Len(sString))
            sHex = Mid(sTmp, pos, 2)
            iDec = Val("&H" & sHex)
            If iDec > 0 Then
                sNew = sNew & Chr(iDec)
            End If
            pos = pos + 2
            Encrypt = False
        End If
        Next
        If Encrypt Then
            hexEncrypt = Chr(163) & sHex
        Else
            hexEncrypt = sNew
        End If
End Function
