VERSION 5.00
Begin VB.Form frmCreateGame 
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "Create Game"
   ClientHeight    =   1860
   ClientLeft      =   45
   ClientTop       =   315
   ClientWidth     =   2070
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmCreateGame.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   1860
   ScaleWidth      =   2070
   StartUpPosition =   2  'CenterScreen
   Begin VB.Frame fmCreateGame 
      Caption         =   "Create Game"
      Height          =   1815
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   2055
      Begin VB.CommandButton cmdStar 
         Caption         =   "StarCraft"
         Height          =   375
         Left            =   120
         TabIndex        =   3
         Top             =   360
         Width           =   1815
      End
      Begin VB.CommandButton cmdWar3 
         Caption         =   "WarCraft III"
         Height          =   375
         Left            =   120
         TabIndex        =   2
         Top             =   720
         Width           =   1815
      End
      Begin VB.CommandButton cmdClose 
         Caption         =   "Close"
         Height          =   375
         Left            =   480
         TabIndex        =   1
         Top             =   1320
         Width           =   1095
      End
   End
End
Attribute VB_Name = "frmCreateGame"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdClose_Click()
    Unload Me
End Sub
Private Sub cmdSexp_Click()
    frmStar.Show
End Sub
Private Sub cmdStar_Click()
    If (BNET.Product = "RATS") Or (BNET.Product = "PXES") Then
        frmStar.Show
        Unload Me
    Else
        MsgBox "You are not on StarCraft"
    End If
End Sub
Private Sub cmdWar3_Click()
    If (BNET.Product = "3RAW") Then
        frmWar3.Show
        Unload Me
    Else
        MsgBox "You are not on WarCraft"
    End If
End Sub

