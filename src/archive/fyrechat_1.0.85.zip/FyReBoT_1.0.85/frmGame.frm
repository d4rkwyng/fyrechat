VERSION 5.00
Begin VB.Form frmGame 
   Caption         =   "Game"
   ClientHeight    =   3195
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4680
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   4680
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton cmdLeave 
      Caption         =   "&Leave Game"
      Height          =   375
      Left            =   3000
      TabIndex        =   5
      Top             =   1080
      Width           =   1455
   End
   Begin VB.CommandButton cmdStart 
      Caption         =   "&Start Game"
      Enabled         =   0   'False
      Height          =   375
      Left            =   3000
      TabIndex        =   4
      Top             =   2640
      Width           =   1455
   End
   Begin VB.CommandButton cmdJoin 
      Caption         =   "&Join"
      Height          =   375
      Left            =   3000
      TabIndex        =   3
      Top             =   720
      Width           =   1455
   End
   Begin VB.CommandButton cmdCreate 
      Caption         =   "&Create"
      Height          =   375
      Left            =   3000
      TabIndex        =   2
      Top             =   360
      Width           =   1455
   End
   Begin VB.TextBox txtPass 
      Height          =   375
      Left            =   360
      TabIndex        =   1
      Top             =   720
      Width           =   1455
   End
   Begin VB.TextBox txtGame 
      Height          =   375
      Left            =   360
      TabIndex        =   0
      Top             =   360
      Width           =   1455
   End
End
Attribute VB_Name = "frmGame"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private GameList As ListView
Private GameLabel As TextBox
Private botPacket As PacketBuffer

Private Sub cmdCreate_Click()
CreateGame txtGame.text, txtPass.text
GameLabel.text = txtGame.text & " / " & txtPass.text
End Sub

Private Sub cmdJoin_Click()
JoinGame txtGame.text, txtPass.text
End Sub

Private Sub cmdLeave_Click()
Dim statstring As String
                statstring = getStatstring(msProduct)
                With frmMain.PacketBuf
                    .InsertNTString username
                    .InsertNTString statstring
                    .SendPacket frmMain.sckBnet, &HA
                    
                    .InsertNonNTString ReverseString(msProduct)
                    .SendPacket frmMain.sckBnet, &HB
                    
                    .InsertBYTE &H2
                    .InsertBYTE &H0
                    .InsertBYTE &H0
                    .InsertBYTE &H0
                    .InsertNTString msChannelName
                    .SendPacket frmMain.sckBnet, &HC
                End With
End Sub

Private Sub cmdStart_Click()
addText "Starting Game" & vbCrLf, ID_COLOR_INFO
With botPacket
    Wait (10)
    .Clear
    .InsertDWORD &H59490100
    .InsertDWORD &H99398E7D
    .InsertDWORD &H7D45DC24
    .InsertDWORD &HF0011E51
    .InsertDWORD &HCA066EA9
    .InsertDWORD &HE2427C45
    .InsertNTString "-(4)Lost Temple.scm"
    .SendPacket frmMain.sckBnet, &H3C
End With
End Sub

'SEND-> 0000   FF 3C 2F 00 59 49 01 00 99 39 8E 7D 45 DC 24 F0    .</.YI...9.}E.$.
'SEND-> 0010   01 1E 51 CA 06 6E A9 E2 42 7C 45 2D 28 34 29 4C    ..Q..n..B|E-(4)L
'SEND-> 0020   6F 73 74 20 54 65 6D 70 6C 65 2E 73 63 6D 00       ost Temple.scm.
'RECV-> 0000   FF 3C 08 00 02 00 00 00                            .<......
'SEND-> 0000   FF 2C 34 02 00 00 00 00 08 00 00 00 03 00 00 00    .,4.............
'SEND-> 0010   03 00 00 00 03 00 00 00 03 00 00 00 03 00 00 00    ................
'SEND-> 0020   03 00 00 00 03 00 00 00 03 00 00 00 65 74 68 62    ............ethb
'SEND-> 0030   6F 74 00 00 00 00 00 00 00 00 4F 6E 20 6D 61 70    ot........On map
'SEND-> 0040   20 22 54 68 65 20 4C 6F 73 74 20 54 65 6D 70 6C     "The Lost Templ
'SEND-> 0050   65 22 3A 0A 00 65 74 68 62 6F 74 20 77 61 73 20    e":..ethbot was
'SEND-> 0060   5A 65 72 67                                        Zerg
'SEND-> 0000   FF 02 04 00                                        ....
'SEND-> 0000   FF 0A 0C 00 65 74 68 62 6F 74 00 00                ....ethbot..
'SEND-> 0000   FF 0B 08 00 50 58 45 53                            ....PXES
'SEND-> 0000   FF 0C 19 00 02 00 00 00 42 72 6F 6F 64 20 57 61    ........Brood Wa
'SEND-> 0010   72 20 55 53 41 2D 31 32 00                         r USA-12.
Private Sub Form_Load()
Set GameList = frmMain.RoomList
Set GameLabel = frmMain.text1
Set botPacket = New PacketBuffer
End Sub

Private Sub Form_Unload(Cancel As Integer)
Set botPacket = Nothing
End Sub
