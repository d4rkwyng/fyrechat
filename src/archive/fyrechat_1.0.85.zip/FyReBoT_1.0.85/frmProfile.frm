VERSION 5.00
Begin VB.Form frmProfile 
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "User's Profile"
   ClientHeight    =   4215
   ClientLeft      =   7995
   ClientTop       =   6285
   ClientWidth     =   4695
   FillColor       =   &H80000012&
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   ForeColor       =   &H00000000&
   Icon            =   "frmProfile.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4215
   ScaleWidth      =   4695
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton cmdSave 
      Caption         =   "&Save"
      Height          =   375
      Left            =   2880
      MaskColor       =   &H8000000F&
      TabIndex        =   11
      Top             =   3720
      Width           =   855
   End
   Begin VB.TextBox txtDescription 
      Height          =   2055
      Left            =   120
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   10
      Top             =   1560
      Width           =   4455
   End
   Begin VB.CommandButton cmdClose 
      Caption         =   "&Close"
      Height          =   375
      Left            =   3720
      MaskColor       =   &H8000000F&
      TabIndex        =   9
      Top             =   3720
      Width           =   855
   End
   Begin VB.TextBox txtLocation 
      Height          =   285
      Left            =   120
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   7
      Top             =   960
      Width           =   4455
   End
   Begin VB.TextBox txtAge 
      Enabled         =   0   'False
      Height          =   285
      Left            =   3360
      MultiLine       =   -1  'True
      TabIndex        =   5
      Top             =   360
      Width           =   1215
   End
   Begin VB.TextBox txtSex 
      Height          =   285
      Left            =   1920
      MultiLine       =   -1  'True
      TabIndex        =   3
      Top             =   360
      Width           =   1335
   End
   Begin VB.TextBox txtUsername 
      Height          =   285
      Left            =   120
      Locked          =   -1  'True
      TabIndex        =   2
      Top             =   360
      Width           =   1695
   End
   Begin VB.Label Label5 
      Caption         =   "Description"
      Height          =   255
      Left            =   120
      TabIndex        =   8
      Top             =   1320
      Width           =   1575
   End
   Begin VB.Label Label4 
      Caption         =   "Location"
      Height          =   255
      Left            =   120
      TabIndex        =   6
      Top             =   720
      Width           =   1215
   End
   Begin VB.Label Label3 
      Caption         =   "Age"
      Height          =   255
      Left            =   3360
      TabIndex        =   4
      Top             =   120
      Width           =   615
   End
   Begin VB.Label Label2 
      Caption         =   "Sex"
      Height          =   255
      Left            =   1920
      TabIndex        =   1
      Top             =   120
      Width           =   495
   End
   Begin VB.Label Label1 
      Caption         =   "Name"
      Height          =   255
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   615
   End
End
Attribute VB_Name = "frmProfile"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Public Sub SetProfile(strUser As String, sex As String, age As String, location As String, Description As String)
    With PBuffer
        .InsertDWORD 1
        .InsertDWORD 4
        .InsertNTString strUser
        .InsertNTString "profile\sex"
        .InsertNTString "profile\age"
        .InsertNTString "profile\location"
        .InsertNTString "profile\description"
        .InsertNTString sex
        .InsertNTString age
        .InsertNTString location
        .InsertNTString Description
        .SendPacket &H27
    End With
End Sub
Private Sub cmdClose_Click()
    Unload frmProfile
    Set frmProfile = Nothing
End Sub
Private Sub cmdSave_Click()
    SetProfile txtUsername.text, txtSex.text, txtAge.text, txtLocation.text, txtDescription.text
    Caption = "Your Profile (Updated)"
    Unload frmProfile
    Set frmProfile = Nothing
End Sub
'Battle.net no longer uses the Age entry.
Private Sub txtAge_KeyPress(KeyAscii As Integer)
    If KeyAscii = 13 Then
        If InStr(txtAge.text, vbCrLf) = 0 Then txtAge.text = txtAge.text & vbCrLf
        txtAge.SelStart = Len(txtAge.text)
    End If
End Sub
Private Sub txtLocation_KeyPress(KeyAscii As Integer)
    If KeyAscii = 13 Then
        If InStr(txtLocation.text, vbCrLf) = 0 Then txtLocation.text = txtLocation.text & vbCrLf
        txtLocation.SelStart = Len(txtLocation.text)
    End If
End Sub
Private Sub txtSex_KeyPress(KeyAscii As Integer)
    If KeyAscii = 13 Then
        If InStr(txtSex.text, vbCrLf) = 0 Then txtSex.text = txtSex.text & vbCrLf
        txtSex.SelStart = Len(txtAge.text)
        End If
End Sub
Private Sub txtUsername_Change()
    If LCase(txtUsername.text) <> LCase(BNET.TrueUsername) Then
        Me.Caption = txtUsername.text & "'s Profile"
        txtAge.Locked = True
        txtSex.Locked = True
        txtLocation.Locked = True
        txtDescription.Locked = True
        cmdSave.Enabled = False
    Else
        Me.Caption = "Your Profile"
        txtAge.Locked = False
        txtSex.Locked = False
        txtLocation.Locked = False
        txtDescription.Locked = False
        cmdSave.Enabled = True
    End If
End Sub
