VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form frmRealm 
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "Diablo II Realms"
   ClientHeight    =   3855
   ClientLeft      =   45
   ClientTop       =   315
   ClientWidth     =   3990
   Icon            =   "frmRealm.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3855
   ScaleWidth      =   3990
   StartUpPosition =   2  'CenterScreen
   Begin VB.Frame Realm 
      Caption         =   "Options"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   3615
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   3735
      Begin VB.Frame Frame1 
         Caption         =   "Realms"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   735
         Left            =   120
         TabIndex        =   9
         Top             =   240
         Width           =   3495
         Begin VB.CommandButton cmdConnect 
            Appearance      =   0  'Flat
            Caption         =   "Connect"
            BeginProperty Font 
               Name            =   "Arial"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   2160
            Style           =   1  'Graphical
            TabIndex        =   12
            Top             =   240
            UseMaskColor    =   -1  'True
            Width           =   1095
         End
         Begin VB.ComboBox lstRealms 
            BeginProperty Font 
               Name            =   "Arial"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   330
            ItemData        =   "frmRealm.frx":C0C2
            Left            =   120
            List            =   "frmRealm.frx":C0D2
            TabIndex        =   11
            Text            =   "USEast"
            Top             =   240
            Width           =   1815
         End
      End
      Begin VB.Frame fmCharMang 
         Caption         =   "Character Manager"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   1095
         Left            =   120
         TabIndex        =   6
         Top             =   960
         Width           =   3495
         Begin VB.CommandButton cmdLogon 
            BackColor       =   &H00808080&
            Caption         =   "Logon"
            BeginProperty Font 
               Name            =   "Arial"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   2160
            TabIndex        =   10
            Top             =   240
            Width           =   1095
         End
         Begin VB.CommandButton cmdDelete 
            Caption         =   "Delete"
            BeginProperty Font 
               Name            =   "Arial"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   2160
            TabIndex        =   8
            Top             =   600
            Width           =   1095
         End
         Begin MSComctlLib.ListView lstCharacter 
            Height          =   735
            Left            =   120
            TabIndex        =   7
            Top             =   240
            Width           =   1815
            _ExtentX        =   3201
            _ExtentY        =   1296
            View            =   3
            Arrange         =   1
            LabelEdit       =   1
            LabelWrap       =   -1  'True
            HideSelection   =   -1  'True
            HideColumnHeaders=   -1  'True
            _Version        =   393217
            ForeColor       =   0
            BackColor       =   -2147483643
            BorderStyle     =   1
            Appearance      =   1
            BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
               Name            =   "Arial"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            NumItems        =   1
            BeginProperty ColumnHeader(1) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
               Text            =   "Channels"
               Object.Width           =   2469
            EndProperty
         End
      End
      Begin VB.Frame fmChar 
         Caption         =   "Create Character"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   1455
         Left            =   120
         TabIndex        =   1
         Top             =   2040
         Width           =   3495
         Begin VB.CommandButton cmdCreateChar 
            BackColor       =   &H00808080&
            Caption         =   "Create"
            BeginProperty Font 
               Name            =   "Arial"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   2160
            TabIndex        =   13
            Top             =   960
            Width           =   1095
         End
         Begin VB.CheckBox chkHardChar 
            Caption         =   "Hardcore"
            BeginProperty Font 
               Name            =   "Arial"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   210
            Left            =   2160
            TabIndex        =   5
            Top             =   360
            Width           =   975
         End
         Begin VB.TextBox txtCreateChar 
            BeginProperty Font 
               Name            =   "Arial"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H80000007&
            Height          =   285
            Left            =   120
            TabIndex        =   4
            Top             =   360
            Width           =   1815
         End
         Begin VB.CheckBox chkExpChar 
            Caption         =   "Expansion"
            BeginProperty Font 
               Name            =   "Arial"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   210
            Left            =   2160
            TabIndex        =   3
            Top             =   600
            Width           =   1095
         End
         Begin VB.ComboBox lstClass 
            BeginProperty Font 
               Name            =   "Arial"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   330
            ItemData        =   "frmRealm.frx":C0F4
            Left            =   120
            List            =   "frmRealm.frx":C10D
            TabIndex        =   2
            Text            =   "Amazon"
            Top             =   840
            Width           =   1815
         End
      End
   End
End
Attribute VB_Name = "frmRealm"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdConnect_Click()
    If cmdConnect.Caption = "Connect" Then
        If frmMain.wsRealm.State = 0 Then ConnectMCP lstRealms.text
        If frmMain.wsBnet.State = 0 Then MsgBox "Currently not connected to battle.net."
    Else
        frmMain.wsRealm.Close
    End If
    If cmdConnect.Caption = "Disconnect" Then frmMain.wsRealm.Close
End Sub
Private Sub cmdCreateChar_Click()
    If frmMain.wsBnet.State = 0 Then
        MsgBox "Currently not connected to battle.net."
    Else
        CreateChar lstClass.text, chkExpChar.value, chkHardChar.value, txtCreateChar.text
    End If
End Sub
Private Sub cmdDelete_Click()
    Dim msg, DChar As String
    If frmMain.wsBnet.State = 0 Then
        MsgBox "Currently not connected to battle.net."
    Else
        DChar = lstCharacter.SelectedItem
        If lstCharacter.SelectedItem.Index > 0 Then
            msg = "Are you sure you want to delete?"
        If MsgBox(msg, vbQuestion + vbYesNo, "Delete " & DChar) = vbNo Then
            Cancel = True
            Exit Sub
        End If
        lstCharacter.ListItems.Remove lstCharacter.SelectedItem.Index
        DeleteChar DChar
        End If
    End If
End Sub
Private Sub cmdLogon_Click()
    If frmMain.wsBnet.State = 0 Then
        MsgBox "Currently not connected to battle.net."
    Else
        If lstCharacter.SelectedItem.Index > 0 Then
            LogonRealmChar lstCharacter.SelectedItem
        Else
            MsgBox "No character selected"
        End If
    End If
End Sub
Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
    Call ExitProgram(Cancel)
End Sub
Private Sub ExitProgram(Cancel As Integer)
    If Urealm Then
        frmRealm.Hide
        Cancel = True
    End If
End Sub

