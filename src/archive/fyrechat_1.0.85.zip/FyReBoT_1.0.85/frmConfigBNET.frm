VERSION 5.00
Begin VB.Form frmConfigBNET 
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "Options"
   ClientHeight    =   6855
   ClientLeft      =   6900
   ClientTop       =   5340
   ClientWidth     =   6390
   FillColor       =   &H80000012&
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmConfigBNET.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6855
   ScaleWidth      =   6390
   StartUpPosition =   2  'CenterScreen
   Begin VB.CheckBox chkPingFlag 
      Caption         =   "Ping:Flags Before Events"
      Height          =   255
      Left            =   3360
      TabIndex        =   41
      Top             =   1920
      Width           =   2295
   End
   Begin VB.ComboBox txtProduct 
      Height          =   330
      ItemData        =   "frmConfigBNET.frx":C0C2
      Left            =   1200
      List            =   "frmConfigBNET.frx":C0D8
      TabIndex        =   36
      Text            =   "None"
      Top             =   1560
      Width           =   1815
   End
   Begin VB.CheckBox chkLagPlug 
      Caption         =   "Negative One Bar"
      Height          =   255
      Left            =   3360
      TabIndex        =   31
      Top             =   1440
      Width           =   2415
   End
   Begin VB.CheckBox chkAutoCon 
      Caption         =   "Auto-Connect on Start"
      Height          =   255
      Left            =   3360
      TabIndex        =   30
      Top             =   720
      Width           =   2415
   End
   Begin VB.CheckBox chkAdBanner 
      Caption         =   "Display AdBanner"
      Height          =   255
      Left            =   3360
      TabIndex        =   29
      Top             =   1680
      Width           =   2415
   End
   Begin VB.CheckBox chkARCon 
      Caption         =   "Auto-Reconnect"
      Height          =   255
      Left            =   3360
      TabIndex        =   24
      Top             =   1200
      Width           =   2415
   End
   Begin VB.CheckBox chkRealms 
      Caption         =   "AutoConnect to Realms"
      Height          =   255
      Left            =   480
      TabIndex        =   22
      Top             =   3600
      Width           =   2055
   End
   Begin VB.Frame frameBattlenet 
      Caption         =   "Connection Setup"
      Height          =   3855
      Left            =   120
      TabIndex        =   8
      Top             =   120
      Width           =   6135
      Begin VB.Frame frameBNLS 
         Caption         =   "BNLS"
         ForeColor       =   &H00000000&
         Height          =   1335
         Left            =   3120
         TabIndex        =   46
         Top             =   2280
         Width           =   2775
         Begin VB.TextBox txtBNLSPass 
            Height          =   285
            IMEMode         =   3  'DISABLE
            Left            =   1080
            PasswordChar    =   "*"
            TabIndex        =   49
            Top             =   600
            Width           =   1575
         End
         Begin VB.TextBox txtBNLSUser 
            Height          =   285
            IMEMode         =   3  'DISABLE
            Left            =   1080
            TabIndex        =   48
            Top             =   240
            Width           =   1575
         End
         Begin VB.TextBox txtBNLS 
            Height          =   285
            Left            =   1080
            TabIndex        =   47
            Top             =   960
            Width           =   1575
         End
         Begin VB.Label lblPassBNLS 
            Caption         =   "Password"
            Height          =   255
            Left            =   120
            TabIndex        =   52
            Top             =   600
            Width           =   975
         End
         Begin VB.Label lblUserBNLS 
            Caption         =   "Username"
            Height          =   255
            Left            =   120
            TabIndex        =   51
            Top             =   240
            Width           =   975
         End
         Begin VB.Label lblBNLS 
            Caption         =   "Server"
            Height          =   255
            Left            =   120
            TabIndex        =   50
            Top             =   960
            Width           =   855
         End
      End
      Begin VB.TextBox txtCharacter 
         ForeColor       =   &H80000007&
         Height          =   285
         Left            =   1080
         TabIndex        =   44
         Top             =   3120
         Width           =   1815
      End
      Begin VB.CheckBox chkLog 
         Caption         =   "Log Chat"
         Height          =   255
         Left            =   3480
         TabIndex        =   39
         Top             =   3000
         Width           =   1095
      End
      Begin VB.CheckBox chkPopup 
         Caption         =   "Pop-Up Notice on Start"
         Height          =   255
         Left            =   3240
         TabIndex        =   38
         Top             =   840
         Width           =   2415
      End
      Begin VB.ComboBox txtBattlenet 
         Height          =   330
         ItemData        =   "frmConfigBNET.frx":C139
         Left            =   1080
         List            =   "frmConfigBNET.frx":C17F
         TabIndex        =   35
         Text            =   "uswest.battle.net"
         Top             =   1080
         Width           =   1815
      End
      Begin VB.TextBox txtCDKeyOwner 
         Height          =   285
         Left            =   1080
         TabIndex        =   13
         Text            =   "FyReBoT v1.0b0"
         Top             =   2520
         Width           =   1815
      End
      Begin VB.TextBox txtCDKey2 
         Height          =   285
         Left            =   1080
         TabIndex        =   12
         Top             =   2160
         Width           =   1815
      End
      Begin VB.TextBox txtCDKey1 
         Height          =   285
         Left            =   1080
         TabIndex        =   11
         Top             =   1800
         Width           =   1815
      End
      Begin VB.TextBox txtPassword 
         ForeColor       =   &H80000007&
         Height          =   285
         IMEMode         =   3  'DISABLE
         Left            =   1080
         PasswordChar    =   "*"
         TabIndex        =   10
         Text            =   "123456"
         Top             =   720
         Width           =   1815
      End
      Begin VB.TextBox txtUsername 
         ForeColor       =   &H80000007&
         Height          =   285
         Left            =   1080
         TabIndex        =   9
         Text            =   "Guest"
         Top             =   360
         Width           =   1815
      End
      Begin VB.Label Label1 
         Caption         =   "Character"
         Height          =   255
         Left            =   120
         TabIndex        =   45
         Top             =   3120
         Width           =   735
      End
      Begin VB.Label lblProduct 
         Caption         =   "Product"
         Height          =   255
         Left            =   120
         TabIndex        =   37
         Top             =   1440
         Width           =   855
      End
      Begin VB.Label lblGenOptions 
         Caption         =   "General Options"
         Height          =   255
         Left            =   3120
         TabIndex        =   23
         Top             =   360
         Width           =   1455
      End
      Begin VB.Label lblD2 
         Caption         =   "Diablo II Options"
         Height          =   255
         Left            =   120
         TabIndex        =   21
         Top             =   2880
         Width           =   1455
      End
      Begin VB.Label lblOwner 
         Caption         =   "Owner"
         Height          =   255
         Left            =   120
         TabIndex        =   19
         Top             =   2520
         Width           =   735
      End
      Begin VB.Label lblLOD 
         Caption         =   "LOD-Key"
         Height          =   255
         Left            =   120
         TabIndex        =   18
         Top             =   2160
         Width           =   735
      End
      Begin VB.Label lblCDkey 
         Caption         =   "CD-key"
         Height          =   255
         Left            =   120
         TabIndex        =   17
         Top             =   1800
         Width           =   735
      End
      Begin VB.Label lblServer 
         Caption         =   "Server"
         Height          =   255
         Left            =   120
         TabIndex        =   16
         Top             =   1080
         Width           =   855
      End
      Begin VB.Label lblPassword 
         Caption         =   "Password"
         Height          =   255
         Left            =   120
         TabIndex        =   15
         Top             =   720
         Width           =   855
      End
      Begin VB.Label lblUsername 
         Caption         =   "Username"
         Height          =   255
         Left            =   120
         TabIndex        =   14
         Top             =   360
         Width           =   975
      End
   End
   Begin VB.Frame frameSetup 
      Caption         =   "Channel Setup"
      Height          =   2175
      Left            =   120
      TabIndex        =   2
      Top             =   4080
      Width           =   6135
      Begin VB.TextBox txtInterval 
         Height          =   285
         Left            =   2040
         TabIndex        =   43
         Text            =   "300"
         Top             =   1800
         Width           =   855
      End
      Begin VB.CheckBox chkEnterLeave 
         Caption         =   "Enter/Leave Notifications"
         Height          =   255
         Left            =   3120
         TabIndex        =   40
         Top             =   720
         Width           =   2415
      End
      Begin VB.CheckBox chkIdle 
         Caption         =   "Normal-Idle"
         Height          =   255
         Left            =   3120
         TabIndex        =   34
         Top             =   1440
         Width           =   2415
      End
      Begin VB.TextBox txtTrigger 
         Height          =   285
         Left            =   1080
         TabIndex        =   33
         Text            =   "."
         Top             =   720
         Width           =   1815
      End
      Begin VB.CheckBox chkCountIdle 
         Caption         =   "Count-Idle (Hmm after 35 Talks)"
         Height          =   255
         Left            =   3120
         TabIndex        =   28
         Top             =   1200
         Width           =   2655
      End
      Begin VB.CheckBox chkAwayIdle 
         Caption         =   "Away-Idle"
         Height          =   255
         Left            =   3120
         TabIndex        =   27
         Top             =   960
         Width           =   2415
      End
      Begin VB.TextBox txtIdle 
         Height          =   285
         Left            =   1080
         TabIndex        =   26
         Text            =   "/me %ver - %time"
         Top             =   1440
         Width           =   1815
      End
      Begin VB.TextBox txtOperator 
         BackColor       =   &H80000013&
         Enabled         =   0   'False
         Height          =   285
         Left            =   1080
         TabIndex        =   25
         Text            =   "Null"
         Top             =   1080
         Width           =   1815
      End
      Begin VB.TextBox txtMaster 
         Height          =   285
         Left            =   1080
         TabIndex        =   20
         Text            =   "Yoda"
         Top             =   360
         Width           =   1815
      End
      Begin VB.TextBox txtHomeChan 
         Height          =   285
         Left            =   3960
         TabIndex        =   3
         Text            =   "Clan RoyalCouncil"
         Top             =   360
         Width           =   1815
      End
      Begin VB.Label lblInterval 
         Caption         =   "Idle-Interval (seconds)"
         Height          =   255
         Left            =   240
         TabIndex        =   42
         Top             =   1800
         Width           =   1815
      End
      Begin VB.Label lblTrigger 
         Caption         =   "Trigger"
         Height          =   255
         Left            =   240
         TabIndex        =   32
         Top             =   720
         Width           =   855
      End
      Begin VB.Label lblIdle 
         Caption         =   "Idle"
         Height          =   255
         Left            =   240
         TabIndex        =   7
         Top             =   1440
         Width           =   855
      End
      Begin VB.Label lblOperator 
         Caption         =   "Operator"
         Height          =   255
         Left            =   240
         TabIndex        =   6
         Top             =   1080
         Width           =   855
      End
      Begin VB.Label lblMaster 
         Caption         =   "Master"
         Height          =   255
         Left            =   240
         TabIndex        =   5
         Top             =   360
         Width           =   855
      End
      Begin VB.Label lblChannel 
         Caption         =   "Channel Setup"
         Height          =   255
         Left            =   3120
         TabIndex        =   4
         Top             =   360
         Width           =   855
      End
   End
   Begin VB.CommandButton cmdCancel 
      Caption         =   "&Cancel"
      Height          =   375
      Left            =   5280
      TabIndex        =   1
      Top             =   6360
      Width           =   975
   End
   Begin VB.CommandButton cmdCommit 
      Caption         =   "&Save"
      Height          =   375
      Left            =   4320
      TabIndex        =   0
      Top             =   6360
      Width           =   975
   End
End
Attribute VB_Name = "frmConfigBNET"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdAddChannel_Click()
    lstChannels.ListItems.Add , , txtAddChannel.text
End Sub

Private Sub cmdBNLS_Click()
    frmBNLS.Show
End Sub
Private Sub cmdCancel_Click()
    Unload frmConfigBNET
    Set frmConfigBNET = Nothing
End Sub
Private Sub cmdCommit_Click()
    BNET.username = txtUsername.text
    BNET.Password = txtPassword.text
    BNET.CDKey = UCase(txtCDKey1.text)
    BNET.CDKey2 = (txtCDKey2.text)
    BNET.CdkeyOwner = txtCDKeyOwner.text
    showClient = Product(txtProduct.text)
    BNET.BattlenetServer = txtBattlenet.text
    
    'Realm Stuff
    BNET.character = txtCharacter.text
    BNET.varCRealm = chkRealms.value
    
    BNET.varAutoCon = chkAutoCon.value
    BNET.varARCon = chkARCon.value
    BNET.varLagPlug = chkLagPlug.value
    BNET.varAdBanner = chkAdBanner.value
    BNET.varPopup = chkPopup.value
    BNET.varPingFlag = chkPingFlag.value
    BNET.varLog = chkLog.value

    BNET.BotMaster = txtMaster.text
    BNET.Trigger = txtTrigger.text
    'BNET.Operator = txtOperator.text
    BNET.Idle = txtIdle.text
    BNET.IdleInt = txtInterval
    BNET.HomeChannel = txtHomeChan.text
    BNET.varEnterLeave = chkEnterLeave.value
    BNET.varCountIdle = chkCountIdle.value
    BNET.varAwayIdle = chkAwayIdle.value
    BNET.varIdle = chkIdle.value
    
    'BNLS
    BNET.BNLSUser = txtBNLSUser.text
    BNET.BNLSPass = txtBNLSPass.text
    BNET.BNLSServer = txtBNLS.text

    SaveConfig
    Unload frmConfigBNET
    Set frmConfigBNET = Nothing
End Sub
Private Sub cmdJoinChan_Click()
    If Len(lstChannels.SelectedItem.text) > 0 Then
        Send "/join " & lstChannels.SelectedItem.text, frmMain.wsBnet
    Else
    End If
End Sub
Private Sub cmdRemoveChan_Click()
    lstChannels.ListItems.Remove lstChannels.SelectedItem.Index
End Sub
Private Sub Form_Load()
    txtUsername.text = BNET.username
    txtPassword.text = BNET.Password
    txtCDKey1.text = UCase(BNET.CDKey)
    txtCDKey2.text = UCase(BNET.CDKey2)
    txtCDKeyOwner.text = BNET.CdkeyOwner
    txtProduct.text = showClient
    txtBattlenet.text = BNET.BattlenetServer
    
    'Realm Stuff
    txtCharacter.text = BNET.character
    chkRealms.value = BNET.varCRealm
    
    chkAutoCon.value = BNET.varAutoCon
    chkARCon.value = BNET.varARCon
    chkLagPlug.value = BNET.varLagPlug
    chkAdBanner.value = BNET.varAdBanner
    chkPopup.value = BNET.varPopup
    chkLog.value = BNET.varLog
    chkPingFlag = BNET.varPingFlag
    
    txtMaster.text = BNET.BotMaster
    txtTrigger.text = BNET.Trigger
    'txtOperator.text = BNET.Operator
    txtIdle.text = BNET.Idle
    txtInterval = BNET.IdleInt
    txtHomeChan.text = BNET.HomeChannel
    chkEnterLeave.value = BNET.varEnterLeave
    chkCountIdle.value = BNET.varCountIdle
    chkAwayIdle.value = BNET.varAwayIdle
    chkIdle.value = BNET.varIdle
    
    'BNLS
    txtBNLSUser.text = BNET.BNLSUser
    txtBNLSPass.text = BNET.BNLSPass
    txtBNLS.text = BNET.BNLSServer
    If txtBNLS.text = "" Then
        txtBNLS.text = "bnls.valhallalegends.com"
    End If
End Sub
Private Sub lstProduct_Click()
    txtProduct.text = lstProduct.List(lstProduct.ListIndex)
End Sub
Public Function Product(Client As String)
    If LCase(Client) = "starcraft" Then
        BNET.Product = "RATS"
    ElseIf LCase(Client) = "starcraft: brood wars" Then
        BNET.Product = "PXES"
    ElseIf LCase(Client) = "diablo ii" Then
        BNET.Product = "VD2D"
    ElseIf LCase(Client) = "lord of destruction" Then
        BNET.Product = "PX2D"
    ElseIf LCase(Client) = "warcraft ii" Then
        BNET.Product = "NB2W"
    ElseIf LCase(Client) = "warcraft iii" Then
        BNET.Product = "3RAW"
    Else
        BNET.Product = "RATS"
    End If
End Function

