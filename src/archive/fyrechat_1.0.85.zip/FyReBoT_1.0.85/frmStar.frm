VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Begin VB.Form frmStar 
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "Starcraft: Create Game"
   ClientHeight    =   5415
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   4695
   FillColor       =   &H8000000F&
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmStar.frx":0000
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5415
   ScaleWidth      =   4695
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton cmdCancel 
      Caption         =   "Clos&e"
      Height          =   375
      Left            =   1680
      TabIndex        =   21
      Top             =   4920
      Width           =   1335
   End
   Begin VB.Frame Frame1 
      Caption         =   "Create Game"
      Height          =   3135
      Left            =   120
      TabIndex        =   6
      Top             =   120
      Width           =   4455
      Begin VB.CommandButton cmdLeave 
         Caption         =   "Leave"
         Height          =   375
         Left            =   3120
         TabIndex        =   22
         Top             =   2640
         Width           =   1095
      End
      Begin VB.TextBox txtGameName 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Left            =   240
         TabIndex        =   14
         Top             =   480
         Width           =   1815
      End
      Begin VB.TextBox txtGamePass 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Left            =   2400
         TabIndex        =   13
         Top             =   480
         Width           =   1935
      End
      Begin VB.TextBox txtGameMap 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Left            =   840
         TabIndex        =   12
         Top             =   960
         Width           =   2175
      End
      Begin VB.CommandButton cmdBrowse 
         Caption         =   "&Browse"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Left            =   3240
         Style           =   1  'Graphical
         TabIndex        =   11
         Top             =   960
         Width           =   1099
      End
      Begin VB.ComboBox txtGameType 
         Height          =   330
         ItemData        =   "frmStar.frx":C0C2
         Left            =   240
         List            =   "frmStar.frx":C0D8
         Style           =   2  'Dropdown List
         TabIndex        =   10
         Top             =   1560
         Width           =   1815
      End
      Begin VB.ComboBox txtGameTeams 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         ItemData        =   "frmStar.frx":C123
         Left            =   2400
         List            =   "frmStar.frx":C13C
         Style           =   2  'Dropdown List
         TabIndex        =   9
         Top             =   1560
         Width           =   1935
      End
      Begin VB.CommandButton cmdCreate 
         Caption         =   "&Create"
         Height          =   375
         Left            =   2040
         TabIndex        =   7
         Top             =   2640
         Width           =   1095
      End
      Begin MSComctlLib.Slider sldGameSpeed 
         Height          =   255
         Left            =   240
         TabIndex        =   8
         Top             =   2280
         Width           =   2415
         _ExtentX        =   4260
         _ExtentY        =   450
         _Version        =   393216
         BorderStyle     =   1
         LargeChange     =   1
         Max             =   6
         SelStart        =   3
         TickStyle       =   3
         Value           =   3
         TextPosition    =   1
      End
      Begin VB.Label Label2 
         BackColor       =   &H00000000&
         BackStyle       =   0  'Transparent
         Caption         =   "Name:"
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   240
         TabIndex        =   20
         Top             =   240
         Width           =   1215
      End
      Begin VB.Label Label3 
         BackColor       =   &H00000000&
         BackStyle       =   0  'Transparent
         Caption         =   "Password:"
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   2400
         TabIndex        =   19
         Top             =   240
         Width           =   1575
      End
      Begin VB.Label Label4 
         BackColor       =   &H00000000&
         BackStyle       =   0  'Transparent
         Caption         =   "Map:"
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   240
         TabIndex        =   18
         Top             =   960
         Width           =   495
      End
      Begin VB.Label Label5 
         BackColor       =   &H00000000&
         BackStyle       =   0  'Transparent
         Caption         =   "Game Type"
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   240
         TabIndex        =   17
         Top             =   1320
         Width           =   1095
      End
      Begin VB.Label Label6 
         BackColor       =   &H00000000&
         BackStyle       =   0  'Transparent
         Caption         =   "Speed:"
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   240
         TabIndex        =   16
         Top             =   2040
         Width           =   615
      End
      Begin VB.Label lblGameSpeed 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         BackStyle       =   0  'Transparent
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   2760
         TabIndex        =   15
         Top             =   2280
         Width           =   1335
      End
   End
   Begin VB.Frame Frame2 
      Caption         =   "Join Game"
      ForeColor       =   &H80000008&
      Height          =   1575
      Left            =   120
      TabIndex        =   0
      Top             =   3240
      Width           =   4455
      Begin VB.TextBox txtJoinName 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Left            =   120
         TabIndex        =   3
         Top             =   600
         Width           =   1815
      End
      Begin VB.TextBox txtJoinPass 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Left            =   2160
         TabIndex        =   2
         Top             =   600
         Width           =   2055
      End
      Begin VB.CommandButton cmdJoinGame 
         Caption         =   "&Join"
         Height          =   375
         Left            =   3120
         TabIndex        =   1
         Top             =   1080
         Width           =   1095
      End
      Begin VB.Label Label8 
         BackColor       =   &H00000000&
         BackStyle       =   0  'Transparent
         Caption         =   "Name:"
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   120
         TabIndex        =   5
         Top             =   360
         Width           =   1095
      End
      Begin VB.Label Label9 
         BackColor       =   &H00000000&
         BackStyle       =   0  'Transparent
         Caption         =   "Password:"
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   2160
         TabIndex        =   4
         Top             =   360
         Width           =   855
      End
   End
   Begin MSComDlg.CommonDialog SelectFile 
      Left            =   240
      Top             =   360
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
End
Attribute VB_Name = "frmStar"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdBrowse_Click()
    SelectFile.DialogTitle = "Choose Map"
    SelectFile.MaxFileSize = 16384
    SelectFile.FileName = ""
    SelectFile.FileName = "StarCraft Maps|*.SMP"
    'SelectFile.ShowOpen
End Sub
Private Sub cmdCancel_Click()
    Unload Me
End Sub
Private Sub cmdCreate_Click()
    Dim gametype As String
    If txtGameType.text = "Melee" Then
        gametype = "2"
    ElseIf txtGameType.text = "Free for All" Then
        gametype = "3"
    ElseIf txtGameType.text = "1 on 1" Then
        gametype = "4"
    ElseIf txtGameType.text = "Ladder" Then
        gametype = "9"
    ElseIf txtGameType.text = "Use Map Settings" Then
        gametype = "A"
    ElseIf txtGameType.text = "Top vs. Bottom" Then
        gametype = "F"
    Else
        gametype = "2"
    End If
    
    CreateGame txtGameName.text, txtGamePass.text, txtGameMap.text, sldGameSpeed.value, gametype
End Sub
Private Sub cmdJoinGame_Click()
    With PBuffer
        .InsertDWORD &HC7
        .InsertNTString frmStar.txtJoinName.text
        .InsertNTString frmStar.txtJoinPass.text
        .SendPacket &H22
    End With
End Sub
Private Sub cmdLeave_Click()
    With PBuffer
        .InsertDWORD 2
        .InsertNTString BNET.CurrentChan
        .SendPacket &HC
    End With
End Sub
Private Sub Form_Load()
    txtGameMap.text = "Challenger"
    lblGameSpeed.Caption = "Normal"
    txtGameType = "Use Map Settings"
End Sub
Private Sub sldGameSpeed_Change()
    If sldGameSpeed.value = "0" Then
        lblGameSpeed.Caption = "Slowest"
    ElseIf sldGameSpeed.value = "1" Then
        lblGameSpeed.Caption = "Slower"
    ElseIf sldGameSpeed.value = "2" Then
        lblGameSpeed.Caption = "Slow"
    ElseIf sldGameSpeed.value = "3" Then
        lblGameSpeed.Caption = "Normal"
    ElseIf sldGameSpeed.value = "4" Then
        lblGameSpeed.Caption = "Fast"
    ElseIf sldGameSpeed.value = "5" Then
        lblGameSpeed.Caption = "Faster"
    Else
        lblGameSpeed.Caption = "Fastest"
    End If
End Sub
Public Function CreateGame(gamename As String, gamePass As String, gamemap As String, gamespeed As String, gametype As String)
    With PBuffer
        .InsertDWORD 0
        .InsertDWORD 0
        .InsertWORD 9
        .InsertWORD 1
        .InsertDWORD &H1F
        .InsertDWORD 0
        .InsertNTString gamename
        .InsertNTString gamePass
        .InsertNonNTString ",34,12," & gamespeed & ",4," & gametype & ",2,ebe6d08d,,,"
        .InsertNonNTString BNET.TrueUsername & Chr(&HD)
        .InsertNTString gamemap & Chr(&HD)
        .SendPacket &H1C
    End With
End Function

