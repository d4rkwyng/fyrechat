VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form frmChannel 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Channel Manager"
   ClientHeight    =   4155
   ClientLeft      =   4275
   ClientTop       =   3525
   ClientWidth     =   5850
   FillColor       =   &H8000000F&
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   ForeColor       =   &H00C0C0C0&
   Icon            =   "frmChannels.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   ScaleHeight     =   4155
   ScaleWidth      =   5850
   Begin VB.Frame Channel 
      Caption         =   "Channel Options"
      ForeColor       =   &H00000000&
      Height          =   2655
      Left            =   3360
      TabIndex        =   4
      Top             =   840
      Width           =   2055
      Begin VB.CommandButton cmdMoveDown 
         BackColor       =   &H00E0E0E0&
         Caption         =   "Move &Down"
         Height          =   375
         Left            =   360
         TabIndex        =   9
         Top             =   1680
         Width           =   1335
      End
      Begin VB.CommandButton cmdMoveUp 
         BackColor       =   &H00E0E0E0&
         Caption         =   "Move U&p"
         Height          =   375
         Left            =   360
         TabIndex        =   8
         Top             =   1200
         Width           =   1335
      End
      Begin VB.CommandButton cmdChkUsrs 
         BackColor       =   &H00E0E0E0&
         Caption         =   "C&heck Users"
         Height          =   375
         Left            =   360
         TabIndex        =   7
         Top             =   720
         Width           =   1335
      End
      Begin VB.CommandButton cmdRemoveChan 
         BackColor       =   &H00E0E0E0&
         Caption         =   "D&elete"
         Height          =   375
         Left            =   360
         TabIndex        =   6
         Top             =   2160
         Width           =   1335
      End
      Begin VB.CommandButton cmdJoinChan 
         BackColor       =   &H00E0E0E0&
         Caption         =   "&Join Channel"
         Height          =   375
         Left            =   360
         TabIndex        =   5
         Top             =   240
         Width           =   1335
      End
   End
   Begin VB.CommandButton cmdDone 
      BackColor       =   &H00E0E0E0&
      Caption         =   "&Close"
      Height          =   375
      Left            =   4440
      TabIndex        =   3
      Top             =   3600
      Width           =   1335
   End
   Begin VB.CommandButton cmdAddChannel 
      BackColor       =   &H00E0E0E0&
      Caption         =   "&Add Channel"
      Height          =   375
      Left            =   3000
      TabIndex        =   2
      Top             =   3600
      Width           =   1335
   End
   Begin VB.TextBox txtAddChannel 
      ForeColor       =   &H00000000&
      Height          =   315
      Left            =   120
      TabIndex        =   1
      Top             =   3600
      Width           =   2775
   End
   Begin MSComctlLib.ListView lstChannels 
      Height          =   3375
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   2775
      _ExtentX        =   4895
      _ExtentY        =   5953
      View            =   3
      Arrange         =   1
      LabelEdit       =   1
      LabelWrap       =   -1  'True
      HideSelection   =   -1  'True
      HideColumnHeaders=   -1  'True
      _Version        =   393217
      ForeColor       =   0
      BackColor       =   -2147483643
      BorderStyle     =   1
      Appearance      =   1
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      NumItems        =   1
      BeginProperty ColumnHeader(1) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         Text            =   "Channels"
         Object.Width           =   3951
      EndProperty
   End
   Begin VB.Label Label1 
      Caption         =   "From here you may join a channel, or customize your favorite Channel list."
      ForeColor       =   &H00000000&
      Height          =   855
      Left            =   3120
      TabIndex        =   10
      Top             =   120
      Width           =   2655
   End
End
Attribute VB_Name = "frmChannel"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Const WM_LBUTTONDBLCLK = &H203
Private Sub cmdAddChannel_Click()
    If Len(txtAddChannel.text) >= 1 Then
        lstChannels.ListItems.Add , , txtAddChannel.text
        frmMain.lstChanSave.ListItems.Add , , txtAddChannel.text
        txtAddChannel.text = ""
    Else
    End If
End Sub
Private Sub cmdChkUsrs_Click()
    If frmMain.wsBnet.State = 7 Then
        Send "/who " & lstChannels.SelectedItem.text, frmMain.wsBnet
    End If
End Sub
Private Sub cmdDone_Click()
    Unload frmChannel
    Set frmChannel = Nothing
End Sub
Private Sub cmdJoinChan_Click()
    If frmMain.wsBnet.State = 7 Then
        If Len(lstChannels.SelectedItem.text) > 0 Then
            Send "/join " & lstChannels.SelectedItem.text, frmMain.wsBnet
        End If
    End If
End Sub
Private Sub cmdMoveDown_Click()
If frmMain.wsBnet.State = 7 Then
    MsgBox ("Not Yet Implemented!")
End If
End Sub
Private Sub cmdMoveUp_Click()
If frmMain.wsBnet.State = 7 Then
    MsgBox ("Not Yet Implemented!")
End If
End Sub
Private Sub cmdRemoveChan_Click()
    If Len(lstChannels.SelectedItem.text) > 1 Then
        lstChannels.ListItems.Remove lstChannels.SelectedItem.Index
        frmMain.lstChanSave.ListItems.Remove lstChannels.SelectedItem.Index + 1
    End If
End Sub
Private Sub lstChannels_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    'If WM_LBUTTONDBLCLK Then
    '    Send "/join " & lstChannels.SelectedItem.text, frmMain.wsBnet
    'End If
End Sub
