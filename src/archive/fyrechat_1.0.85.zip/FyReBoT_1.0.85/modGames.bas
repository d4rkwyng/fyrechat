Attribute VB_Name = "modGames"
Public Function IPtoDWORD(ByRef IP1 As String) As Long
    Dim b1 As Integer, b2 As Integer, b3 As Integer, b4 As Integer
    Dim IP As String
    IP = IP1
    If IP = "" Then
        IPtoDWORD = 1
        Exit Function
    End If
    b1 = Val(Mid(IP, 1, InStr(IP, ".") - 1))
    IP = Mid(IP, InStr(IP, ".") + 1)
    b2 = Val(Mid(IP, 1, InStr(IP, ".") - 1))
    IP = Mid(IP, InStr(IP, ".") + 1)
    b3 = Val(Mid(IP, 1, InStr(IP, ".") - 1))
    IP = Mid(IP, InStr(IP, ".") + 1)
    b4 = Val(Mid(IP, InStr(IP, ".") + 1))
End Function
Public Function DWORDtoIP(dword As Long) As String
    Dim Number As String
    If dword = 0 Then Exit Function
    Number = Hex(dword)

    b1 = Mid(Number, 1, 2)
    b2 = Mid(Number, 3, 2)
    b3 = Mid(Number, 5, 2)
    b4 = Mid(Number, 7, 2)

    DWORDtoIP = Val("&H" & b4) & "." & Val("&H" & b3) & "." & Val("&H" & b2) & "." & Val("&H" & b1)
End Function
