Attribute VB_Name = "modDeclares"
'Public Declares
Public Declare Function GetTickCount Lib "kernel32.dll" () As Long
Public Declare Sub CopyMemory Lib "kernel32" Alias "RtlMoveMemory" (ByRef Destination As Any, ByRef Source As Any, ByVal numBytes As Long)
Public Declare Function WritePrivateProfileString Lib "kernel32" Alias "WritePrivateProfileStringA" (ByVal lpApplicationName As String, ByVal lpKeyName As Any, ByVal lpString As Any, ByVal lpFileName As String) As Long
Public Declare Function GetPrivateProfileString Lib "kernel32" Alias "GetPrivateProfileStringA" (ByVal lpApplicationName As String, ByVal lpKeyName As Any, ByVal lpDefault As String, ByVal lpReturnedString As String, ByVal nSize As Long, ByVal lpFileName As String) As Long
Public Declare Function ShellExecute Lib "shell32.dll" Alias "ShellExecuteA" (ByVal HWnd As Long, ByVal lpOperation As String, ByVal lpFile As String, ByVal lpParameters As String, ByVal lpDirectory As String, ByVal nShowCmd As Long) As Long
Public Declare Function SetWindowLong Lib "user32.dll" Alias "SetWindowLongA" (ByVal HWnd As Long, ByVal nIndex As Long, ByVal dwNewLong As Long) As Long
Public Declare Function CallWindowProc Lib "user32.dll" Alias "CallWindowProcA" (ByVal lpPrevWndFunc As Long, ByVal HWnd As Long, ByVal msg As Long, ByVal wParam As Long, ByVal lParam As Long) As Long
Public Declare Sub RtlMoveMemory Lib "kernel32.dll" (Destination As Any, Source As Any, ByVal Length As Long)
Public Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)
Public Declare Function SendMessage Lib "user32" Alias "SendMessageA" (ByVal HWnd As Long, ByVal wMsg As Long, ByVal wParam As Long, lParam As Any) As Long
Public Declare Function A2 Lib "bnetauth.dll" (ByVal outbuf As String, ByVal key As Long) As Long
Public Declare Function PathIsDirectory Lib "shlwapi.dll" Alias "PathIsDirectoryA" (ByVal pszPath As String) As Long
Public Declare Function CreateDirectory Lib "kernel32" Alias "CreateDirectoryA" (ByVal lpPathName As String, lpSecurityAttributes As SECURITY_ATTRIBUTES) As Long

'Colors
Public Const vbD2Tan = &H6396A5
Public Const vbD2Grey = &H595959
Public Const vbD2LGrey = &HB5B2B5
Public Const vbD2Red = &H4241D6
Public Const vbD2Green = &HCF00&
Public Const vbD2Orange = &H8AD6&
Public Const vbD2Blue = &HD65552
Public Const vbD2Yellow = &H52CFD6
Public Const vbD2Black = &H80808

Public Type SECURITY_ATTRIBUTES
    nLength As Long
    lpSecurityDescriptor As Long
    bInheritHandle As Long
End Type


'Public Constants
Public Const CRC32_POLYNOMIAL As Long = &HEDB88320
Public Const vbGrey = &H808080

'Idle Variables (enum)
Public Enum TimeFormatType
    DaysHoursMinutesSecondsMilliseconds = 0
    DaysHoursMinutesSeconds = 1
    DHMSMColonSeparated = 2
    DaysHoursMinutes = 3
End Enum

'WinAmp Variables
Public Const WS_VOLUMEUP = 40058
Public Const WS_VOLUMEDOWN = 40059
Public Const WS_PREV = 40044
Public Const WS_NEXT = 40048
Public Const WS_PLAY = 40045
Public Const WS_PAUSE = 40046
Public Const WS_STOP = 40047
Public Const WS_FFWD = 40060
Public Const WS_RWND = 40061
Public Const MAX = 128

'Config.ini Variables
Public Type BotData
    username        As String
    TrueUsername    As String
    Password        As String
    CDKey           As String
    CDKey2          As String
    CdkeyOwner      As String
    BattlenetServer As String
    BNLS            As String
    BNLSUser        As String
    BNLSPass        As String
    BNLSServer      As String
    HomeChannel     As String
    Product         As String
    character       As String
    varCRealm       As String
    NewPass         As String 'Not Used
    CurrentChan     As String
    BotMaster       As String
    varARCon        As String
    varEnterLeave   As String
    varAwayIdle     As String
    varCountIdle    As String
    varIdle         As String
    Idle            As String
    IdleInt         As String
    varAutoCon      As String
    varLagPlug      As String
    varAdBanner        As String
    Trigger         As String
    Notice          As String
    varPopup        As String
    varLog          As String
    varPingFlag     As String
End Type
Public BNET      As BotData
Public PBuffer   As New PacketBuffer
Public packetbuf As New PacketBuffer

Public Version     As Long
Public Checksum    As Long
Public ExeInfo     As String
Public Servers     As Long
Public CdkeyHash   As String
Public Cdkey2Hash  As String
Public GTC         As Long
Public HType       As Long
Public CB          As Long
Public SPass       As Boolean
Public VerByte     As Long
Public P1          As String
Public P2          As String
Public AttemptedC  As Boolean
Public CRC32Table(0 To 255) As Long
Public Hash(2)     As String
Public Temporary   As String
Public LastTalk    As Long
Public IdleIO      As Long
Public RunningTime As Long
Public connecttime As Long
Public awayFlag    As Boolean
Public idleFlag    As Boolean
Public msPerson    As String 'Channel PopUp Access
Public msGame      As String 'Used for Profile Requesting
Public Whisper     As Boolean
Public WReply      As String 'Replies to last user who whispered.
Public LastViewProfile As String
Public usrtmp      As String
Public varProfileChecked As String
Public varLagPlug  As String
Public vbMax       As Boolean
Public MOverwrite  As Boolean
Public MyPing      As Long
Public MyFlags      As Long
Public fHandle     As Long
Public colProfiles As New Collection
Public varRequestType As String
Public RealmName As String
Public StarRealm As Boolean
Public PathFolder As Boolean
Public showClient As String
Public IdleSent As String
Public hmm As Long
Public PType As String
Public GameWins As String
Public chrClass As String
Public dots As String
Public Urealm As Boolean
Public RaceIcon As String

'System Tray Variables
 Type NOTIFYICONDATA
    cbSize           As Long
    HWnd             As Long
    uId              As Long
    uFlags           As Long
    uCallBackMessage As Long
    hIcon            As Long
    szTip            As String * 64
 End Type
 
 Declare Function Shell_NotifyIcon Lib "shell32" _
    Alias "Shell_NotifyIconA" _
    (ByVal dwMessage As Long, pnid As NOTIFYICONDATA) As Boolean
 Global nid As NOTIFYICONDATA

Declare Function SetWindowPos Lib "user32" _
    (ByVal HWnd As Long, _
    ByVal hWndInsertAfter As Long, _
    ByVal X As Long, _
    ByVal Y As Long, _
    ByVal cx As Long, _
    ByVal cy As Long, _
    ByVal wFlags As Long) As Long

'AutoDetectURL
Public Const GWL_WNDPROC = (-4)
Public Const WM_USER = &H400
Public Const WM_NOTIFY = &H4E
Public Const WM_LBUTTONDOWN = &H201
Public Const EM_GETEVENTMASK = WM_USER + 59
Public Const EM_GETTEXTRANGE = WM_USER + 75
Public Const EM_AUTOURLDETECT = (WM_USER + 91)
Public Const EM_SETEVENTMASK = WM_USER + 69
Public Const EN_LINK = &H70B
Public Const ENM_LINK = &H4000000
Public Const SW_SHOWNORMAL = 1

Type tagNMHDR
    hwndFrom As Long
    idFrom   As Long
    code     As Long
End Type

Type CHARRANGE
    cpMin As Long
    cpMax As Long
End Type

Type ENLINK
    nmhdr  As tagNMHDR
    msg    As Long
    wParam As Long
    lParam As Long
    chrg   As CHARRANGE
End Type

Type TEXTRANGE
    chrg      As CHARRANGE
    lpstrText As Long
End Type

Public glnglpOriginalWndProc As Long
Public glngOriginalhWnd As Long
Public Function RichTextBoxSubProc(ByVal HWnd As Long, ByVal uMsg As Long, ByVal wParam As Long, ByVal lParam As Long) As Long
    Dim udtNMHDR               As tagNMHDR
    Dim udtENLINK              As ENLINK
    Dim udtTEXTRANGE           As TEXTRANGE
    Dim strBuffer              As String * 128
    Dim strOperation           As String
    Dim strFileName            As String
    Dim strDefaultDirectory    As String
    Dim lngHInstanceExecutable As Long
    Dim lngWin32apiResultCode  As Long

    If uMsg = WM_NOTIFY Then
        RtlMoveMemory udtNMHDR, ByVal lParam, Len(udtNMHDR)
        If udtNMHDR.hwndFrom = frmMain.rtbChat.HWnd And udtNMHDR.code = EN_LINK Then
            RtlMoveMemory udtENLINK, ByVal lParam, Len(udtENLINK)
            If udtENLINK.msg = WM_LBUTTONDOWN Then
                strBuffer = ""
                With udtTEXTRANGE
                    .chrg.cpMin = udtENLINK.chrg.cpMin
                    .chrg.cpMax = udtENLINK.chrg.cpMax
                    .lpstrText = StrPtr(strBuffer)
                End With
                With frmMain.rtbChat
                    lngWin32apiResultCode = SendMessage(.HWnd, EM_GETTEXTRANGE, 0, udtTEXTRANGE)
                End With
                RtlMoveMemory ByVal strBuffer, ByVal udtTEXTRANGE.lpstrText, Len(strBuffer)
                strOperation = "open"
                strFileName = strBuffer
                lngHInstanceExecutable = ShellExecute(frmMain.HWnd, strOperation, strFileName, vbNullString, strDefaultDirectory, SW_SHOWNORMAL)
            End If
        ElseIf udtNMHDR.hwndFrom = frmMain.rtbWhisper.HWnd And udtNMHDR.code = EN_LINK Then
        RtlMoveMemory udtENLINK, ByVal lParam, Len(udtENLINK)
        If udtENLINK.msg = WM_LBUTTONDOWN Then
            strBuffer = ""
            With udtTEXTRANGE
                .chrg.cpMin = udtENLINK.chrg.cpMin
                .chrg.cpMax = udtENLINK.chrg.cpMax
                .lpstrText = StrPtr(strBuffer)
            End With
            With frmMain.rtbWhisper
                lngWin32apiResultCode = SendMessage(.HWnd, EM_GETTEXTRANGE, 0, udtTEXTRANGE)
            End With
            RtlMoveMemory ByVal strBuffer, ByVal udtTEXTRANGE.lpstrText, Len(strBuffer)
            strOperation = "open"
            strFileName = strBuffer
            lngHInstanceExecutable = ShellExecute(frmMain.HWnd, strOperation, strFileName, vbNullString, strDefaultDirectory, SW_SHOWNORMAL)
        End If
    End If
End If
RichTextBoxSubProc = CallWindowProc(glnglpOriginalWndProc, HWnd, uMsg, wParam, lParam)
End Function
