VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form frmWar3 
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "W3: Arranged Team"
   ClientHeight    =   3390
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   2415
   FillColor       =   &H8000000F&
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmWar3.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3390
   ScaleWidth      =   2415
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton cmdRefresh 
      BackColor       =   &H00808080&
      Caption         =   "&Refresh"
      Height          =   375
      Left            =   120
      TabIndex        =   3
      Top             =   2520
      Width           =   2175
   End
   Begin VB.CommandButton cmdCancel 
      BackColor       =   &H00808080&
      Caption         =   "&Cancel"
      Height          =   375
      Left            =   120
      TabIndex        =   2
      Top             =   2880
      Width           =   2175
   End
   Begin VB.CommandButton cmdInvite 
      BackColor       =   &H00808080&
      Caption         =   "&Invite"
      Height          =   375
      Left            =   120
      TabIndex        =   1
      Top             =   2160
      Width           =   2175
   End
   Begin MSComctlLib.ListView InviteUsers 
      Height          =   1935
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   2175
      _ExtentX        =   3836
      _ExtentY        =   3413
      View            =   3
      LabelEdit       =   1
      LabelWrap       =   -1  'True
      HideSelection   =   -1  'True
      HideColumnHeaders=   -1  'True
      Checkboxes      =   -1  'True
      _Version        =   393217
      ForeColor       =   -2147483640
      BackColor       =   -2147483643
      BorderStyle     =   1
      Appearance      =   1
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      NumItems        =   1
      BeginProperty ColumnHeader(1) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         Text            =   "Username"
         Object.Width           =   5292
      EndProperty
   End
End
Attribute VB_Name = "frmWar3"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdCancel_Click()
    Unload Me
End Sub
Private Sub cmdInvite_Click()
    Dim names As String
    For i = 1 To InviteUsers.ListItems.Count
        If InviteUsers.ListItems(i).Checked Then
            names = names & Chr(0) & InviteUsers.ListItems(i)
        End If
    Next i
    Dim List() As String
    List() = Split(names, Chr(0))
    PBuffer.InsertDWORD &H1
    PBuffer.InsertDWORD &H203E460
    PBuffer.InsertDWORD &H1
    PBuffer.InsertBYTE UBound(List)
    For i = 1 To UBound(List)
        PBuffer.InsertNTString List(i)
    Next i
    PBuffer.SendPacket &H61
    AddChat vbD2Tan, "Inviting users.."
End Sub
Private Sub Form_Load()
    PBuffer.InsertDWORD &H1C
    PBuffer.InsertDWORD &H0
    PBuffer.InsertNTString "matchmaking-war3-enUS.dat"
    PBuffer.SendPacket &H33
End Sub
