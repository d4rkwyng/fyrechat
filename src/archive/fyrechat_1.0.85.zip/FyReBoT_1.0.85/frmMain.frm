VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Object = "{248DD890-BB45-11CF-9ABC-0080C7E7B78D}#1.0#0"; "mswinsck.ocx"
Object = "{3B7C8863-D78F-101B-B9B5-04021C009402}#1.2#0"; "richtx32.ocx"
Begin VB.Form frmMain 
   Caption         =   "FyReBoT - Copyright (C) 2003 FyRe"
   ClientHeight    =   5730
   ClientLeft      =   210
   ClientTop       =   405
   ClientWidth     =   9240
   FillColor       =   &H80000012&
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmMain.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   5730
   ScaleWidth      =   9240
   StartUpPosition =   2  'CenterScreen
   Begin VB.Timer tmrBanner 
      Enabled         =   0   'False
      Interval        =   30000
      Left            =   2520
      Top             =   7920
   End
   Begin MSComctlLib.ListView lstChanSave 
      Height          =   375
      Left            =   3720
      TabIndex        =   3
      Top             =   7920
      Visible         =   0   'False
      Width           =   1335
      _ExtentX        =   2355
      _ExtentY        =   661
      LabelWrap       =   -1  'True
      HideSelection   =   -1  'True
      _Version        =   393217
      ForeColor       =   -2147483640
      BackColor       =   -2147483643
      BorderStyle     =   1
      Appearance      =   1
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      NumItems        =   0
   End
   Begin VB.Timer TimerAway 
      Interval        =   30000
      Left            =   2040
      Top             =   7920
   End
   Begin VB.Timer TimerIdle 
      Interval        =   1000
      Left            =   1560
      Top             =   7920
   End
   Begin VB.ComboBox txtSendBNET 
      BackColor       =   &H00000000&
      ForeColor       =   &H00FFFFFF&
      Height          =   330
      Left            =   0
      TabIndex        =   2
      Top             =   7560
      Width           =   8655
   End
   Begin MSWinsockLib.Winsock wsBnls 
      Left            =   600
      Top             =   7920
      _ExtentX        =   741
      _ExtentY        =   741
      _Version        =   393216
   End
   Begin MSWinsockLib.Winsock wsBnet 
      Left            =   240
      Top             =   7920
      _ExtentX        =   741
      _ExtentY        =   741
      _Version        =   393216
   End
   Begin MSComctlLib.ListView lstChannel 
      Height          =   7335
      Left            =   8760
      TabIndex        =   1
      Top             =   360
      Width           =   2535
      _ExtentX        =   4471
      _ExtentY        =   12938
      View            =   3
      Arrange         =   1
      LabelEdit       =   1
      LabelWrap       =   -1  'True
      HideSelection   =   0   'False
      HideColumnHeaders=   -1  'True
      AllowReorder    =   -1  'True
      _Version        =   393217
      Icons           =   "ImgLst"
      SmallIcons      =   "ImgLst"
      ForeColor       =   16777215
      BackColor       =   0
      Appearance      =   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      NumItems        =   2
      BeginProperty ColumnHeader(1) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         Text            =   "User"
         Object.Width           =   3704
      EndProperty
      BeginProperty ColumnHeader(2) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   1
         Object.Tag             =   "Ping"
         Text            =   "Ping"
         Object.Width           =   882
      EndProperty
   End
   Begin VB.TextBox txtChannelInfo 
      Alignment       =   2  'Center
      BackColor       =   &H00000000&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   285
      Left            =   8760
      Locked          =   -1  'True
      TabIndex        =   0
      Top             =   0
      Width           =   2535
   End
   Begin RichTextLib.RichTextBox rtbWhisper 
      Height          =   1815
      Left            =   0
      TabIndex        =   4
      Top             =   5760
      Width           =   8655
      _ExtentX        =   15266
      _ExtentY        =   3201
      _Version        =   393217
      BackColor       =   0
      Enabled         =   -1  'True
      ReadOnly        =   -1  'True
      ScrollBars      =   2
      TextRTF         =   $"frmMain.frx":C0C2
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin RichTextLib.RichTextBox rtbChat 
      Height          =   5775
      Left            =   0
      TabIndex        =   5
      Top             =   0
      Width           =   8655
      _ExtentX        =   15266
      _ExtentY        =   10186
      _Version        =   393217
      BackColor       =   0
      Enabled         =   -1  'True
      ReadOnly        =   -1  'True
      ScrollBars      =   2
      TextRTF         =   $"frmMain.frx":C139
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin MSWinsockLib.Winsock wsRealm 
      Left            =   1080
      Top             =   7920
      _ExtentX        =   741
      _ExtentY        =   741
      _Version        =   393216
   End
   Begin MSComctlLib.ImageList ImgLst 
      Left            =   3000
      Top             =   7920
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   0
      ImageWidth      =   28
      ImageHeight     =   14
      MaskColor       =   12632256
      UseMaskColor    =   0   'False
      _Version        =   393216
      BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
         NumListImages   =   29
         BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":C1B0
            Key             =   ""
         EndProperty
         BeginProperty ListImage2 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":C69A
            Key             =   ""
         EndProperty
         BeginProperty ListImage3 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":CB84
            Key             =   ""
         EndProperty
         BeginProperty ListImage4 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":D19E
            Key             =   ""
         EndProperty
         BeginProperty ListImage5 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":D6DC
            Key             =   ""
         EndProperty
         BeginProperty ListImage6 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":DBC6
            Key             =   ""
         EndProperty
         BeginProperty ListImage7 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":E0B0
            Key             =   ""
         EndProperty
         BeginProperty ListImage8 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":E59A
            Key             =   ""
         EndProperty
         BeginProperty ListImage9 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":EB74
            Key             =   ""
         EndProperty
         BeginProperty ListImage10 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":F05E
            Key             =   ""
         EndProperty
         BeginProperty ListImage11 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":F548
            Key             =   ""
         EndProperty
         BeginProperty ListImage12 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":FA32
            Key             =   ""
         EndProperty
         BeginProperty ListImage13 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":FF1C
            Key             =   ""
         EndProperty
         BeginProperty ListImage14 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":10408
            Key             =   ""
         EndProperty
         BeginProperty ListImage15 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":108F2
            Key             =   ""
         EndProperty
         BeginProperty ListImage16 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":10DDE
            Key             =   ""
         EndProperty
         BeginProperty ListImage17 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":112C8
            Key             =   ""
         EndProperty
         BeginProperty ListImage18 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":117B2
            Key             =   ""
         EndProperty
         BeginProperty ListImage19 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":11C9C
            Key             =   ""
         EndProperty
         BeginProperty ListImage20 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":12186
            Key             =   ""
         EndProperty
         BeginProperty ListImage21 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":12672
            Key             =   ""
         EndProperty
         BeginProperty ListImage22 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":12B5C
            Key             =   ""
         EndProperty
         BeginProperty ListImage23 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":13046
            Key             =   ""
         EndProperty
         BeginProperty ListImage24 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":13530
            Key             =   ""
         EndProperty
         BeginProperty ListImage25 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":13A1A
            Key             =   ""
         EndProperty
         BeginProperty ListImage26 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":13F04
            Key             =   ""
         EndProperty
         BeginProperty ListImage27 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":143EE
            Key             =   ""
         EndProperty
         BeginProperty ListImage28 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":148D8
            Key             =   ""
         EndProperty
         BeginProperty ListImage29 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":14DC2
            Key             =   ""
         EndProperty
      EndProperty
   End
   Begin MSWinsockLib.Winsock sckBnet 
      Index           =   0
      Left            =   5640
      Top             =   7920
      _ExtentX        =   741
      _ExtentY        =   741
      _Version        =   393216
      RemotePort      =   6112
   End
   Begin VB.Menu mnuFile 
      Caption         =   "File"
      Begin VB.Menu mnuConnect 
         Caption         =   "Connect"
      End
      Begin VB.Menu mnuDisconnect 
         Caption         =   "Disconnect"
         Enabled         =   0   'False
      End
      Begin VB.Menu sep6 
         Caption         =   "-"
      End
      Begin VB.Menu mnuReconnect 
         Caption         =   "Reconnect"
         Enabled         =   0   'False
      End
      Begin VB.Menu sep1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuExit 
         Caption         =   "Close"
      End
   End
   Begin VB.Menu mnuTools 
      Caption         =   "Tools"
      Begin VB.Menu mnuChannel 
         Caption         =   "Channels"
      End
      Begin VB.Menu mnuGames 
         Caption         =   "Games"
      End
      Begin VB.Menu mnuRealms 
         Caption         =   "Realms"
      End
      Begin VB.Menu sep10 
         Caption         =   "-"
      End
      Begin VB.Menu mnuSetupOption 
         Caption         =   "Options"
      End
   End
   Begin VB.Menu mnuActions 
      Caption         =   "Actions"
      Begin VB.Menu mnuClearChat 
         Caption         =   "Clear Chat"
      End
      Begin VB.Menu mnuClearWhisper 
         Caption         =   "Clear Whisper"
      End
   End
   Begin VB.Menu mnuAbout 
      Caption         =   "About"
   End
   Begin VB.Menu mnuOptions 
      Caption         =   "Options"
      Visible         =   0   'False
      Begin VB.Menu mnuClearC 
         Caption         =   "Clear Chat"
      End
      Begin VB.Menu sep14 
         Caption         =   "-"
      End
      Begin VB.Menu mnuCopy 
         Caption         =   "Copy"
      End
      Begin VB.Menu mnuQuoteAdd 
         Caption         =   "Add to Quotes"
         Visible         =   0   'False
      End
   End
   Begin VB.Menu mnuTray 
      Caption         =   "System Tray"
      Visible         =   0   'False
      Begin VB.Menu mnuTrayRestore 
         Caption         =   "Restore"
         Enabled         =   0   'False
      End
      Begin VB.Menu sep12 
         Caption         =   "-"
      End
      Begin VB.Menu mnuTrayExit 
         Caption         =   "Exit"
         Enabled         =   0   'False
      End
   End
   Begin VB.Menu mnuList 
      Caption         =   "List"
      Visible         =   0   'False
      Begin VB.Menu mnuWhois 
         Caption         =   "Whois"
      End
      Begin VB.Menu mnuStatS 
         Caption         =   "Stats"
         Begin VB.Menu mnuStatSTAR 
            Caption         =   "Starcraft"
         End
         Begin VB.Menu mnuStatSEXP 
            Caption         =   "Starcraft: Brood Wars"
         End
         Begin VB.Menu mnuStatW2BN 
            Caption         =   "Warcraft II: Battle.net Edition"
         End
         Begin VB.Menu mnuStatWAR3 
            Caption         =   "Warcraft III: Reign of Chaos"
         End
         Begin VB.Menu mnuStatW3XP 
            Caption         =   "Warcraft III: The Frozen Throne"
            Enabled         =   0   'False
         End
      End
      Begin VB.Menu mnuFriendList 
         Caption         =   "Friends List"
         Begin VB.Menu mnuFriendAdd 
            Caption         =   "Add"
         End
         Begin VB.Menu mnuFriendRemove 
            Caption         =   "Remove"
         End
         Begin VB.Menu mnuFriendPromote 
            Caption         =   "Promote"
         End
         Begin VB.Menu mnuFriendDemote 
            Caption         =   "Demote"
         End
      End
      Begin VB.Menu mnuCopyName 
         Caption         =   "Copy Name"
      End
      Begin VB.Menu mnuViewProfile 
         Caption         =   "View Profile"
      End
      Begin VB.Menu sep8 
         Caption         =   "-"
      End
      Begin VB.Menu mnuBan 
         Caption         =   "Ban"
      End
      Begin VB.Menu mnuKick 
         Caption         =   "Kick"
      End
      Begin VB.Menu mnuDesignate 
         Caption         =   "Designate"
      End
      Begin VB.Menu mnuSquelch 
         Caption         =   "Squelch"
      End
      Begin VB.Menu mnuUnsquelch 
         Caption         =   "Unsquelch"
      End
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Public WithEvents ChatBot As BnetBot
Attribute ChatBot.VB_VarHelpID = -1
Private Sub Form_Load()
    Call AddToTray(Me.Icon, App.ProductName, Me)
    RunningTime = GetTickCount
    LoadConfig
    
    PType = " (Public)"
    BNET.Notice = GetStuff("BOT", "notice")

    If BNET.Notice = "" Then BNET.Notice = "Welcome to " & App.Title & " version " & App.Major & "." & App.Minor & " build " & App.Revision & PType
    If BNET.varPopup = 1 Then
        MsgBox BNET.Notice
    End If
    Dim lngEventMask As Long
    Dim lngWin32apiResultCode As Long
    awayFlag = False
    idleFlag = False
    Whisper = False
    MOverwrite = True
    Urealm = True
    
    '// auto detect urls
    With rtbChat
        lngEventMask = SendMessage(.HWnd, EM_GETEVENTMASK, 0, ByVal CLng(0))
        If lngEventMask Xor ENM_LINK Then
            lngEventMask = lngEventMask Or ENM_LINK
        End If
        lngWin32apiResultCode = SendMessage(.HWnd, EM_SETEVENTMASK, 0, ByVal CLng(lngEventMask))
        lngWin32apiResultCode = SendMessage(.HWnd, EM_AUTOURLDETECT, CLng(1), ByVal CLng(0))
    End With
    With rtbWhisper
        lngEventMask = SendMessage(.HWnd, EM_GETEVENTMASK, 0, ByVal CLng(0))
        If lngEventMask Xor ENM_LINK Then
            lngEventMask = lngEventMask Or ENM_LINK
        End If
        lngWin32apiResultCode = SendMessage(.HWnd, EM_SETEVENTMASK, 0, ByVal CLng(lngEventMask))
        lngWin32apiResultCode = SendMessage(.HWnd, EM_AUTOURLDETECT, CLng(1), ByVal CLng(0))
    End With
    glngOriginalhWnd = Me.HWnd
    glnglpOriginalWndProc = SetWindowLong(glngOriginalhWnd, GWL_WNDPROC, AddressOf RichTextBoxSubProc)

    Set ChatBot = New BnetBot

    frmMain.Caption = App.Title & " - Copyright � 1/1/03 - 3/17/03 FyRe - version " & App.Major & "." & App.Minor & "." & App.Revision & "."
    AddChat vbD2Tan, App.Title & " - Copyright � 1/1/03 - 3/17/03 FyRe - version " & App.Major & "." & App.Minor & "." & App.Revision & "."
    AddChat vbD2Tan, "FSI Production: http://fyrebot.efyre.com"
    AddChat vbD2Tan, "Public build - Distribution of any kind is permitted!"
    
    'Connect on Start option
    If BNET.varAutoCon = 1 Then mnuConnect_Click
End Sub
Private Sub Form_Resize()
    On Error Resume Next

    rtbChat.Height = Me.Height - 2800
    rtbChat.Width = Me.Width - 3025
    rtbWhisper.Width = rtbChat.Width
    rtbWhisper.Top = Me.ScaleHeight - 2150
    txtSendBNET.Width = rtbChat.Width
    txtSendBNET.Top = Me.ScaleHeight - 350
    lstChannel.Left = Me.Width - 3000
    lstChannel.Height = (rtbChat.Height + rtbWhisper.Height + txtChannelInfo.Height) - 400
    lstChannel.Width = 2900
    txtChannelInfo.Width = lstChannel.Width
    txtChannelInfo.Left = Me.Width - 3000
End Sub
Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
    If wsBnet.State = 7 And MOverwrite Then Call ExitProgram(Cancel)
    If wsBnet.State = 0 Then Call ExitFinal
End Sub
Private Sub ExitProgram(Cancel As Integer)
    Dim msg
    msg = "Are you sure you want to close while connected?"
    If MsgBox(msg, vbQuestion + vbYesNo, App.Title & " - Logged on as: " & BNET.username) = vbNo Then
        Cancel = True
        Exit Sub
    End If
    If frmMain.WindowState = vbMinimized Then Call RemoveFromTray
    AddChat vbGrey, "Session Terminated" & vbNewLine
    Close #fHandle
    Call ExitFinal
End Sub
Private Sub ExitFinal()
    Unload frmAbout
    Unload frmChannel
    Unload frmConfigBNET
    Unload frmCreateGame
    Unload frmProfile
    Urealm = False
    Unload frmRealm
    Unload frmStar
    Unload frmW3Invited
    Unload frmWar3
End Sub
Private Sub mnuAbout_Click()
    frmAbout.Show
End Sub
Private Sub mnuChannel_Click()
    Dim LCount As Integer
    LCount = frmMain.lstChanSave.ListItems.Count
    For i = 1 To LCount
        frmChannel.lstChannels.ListItems.Add , , frmMain.lstChanSave.ListItems(i)
    Next i
    frmChannel.Show
End Sub
Private Sub mnuClearChat_Click()
    frmMain.rtbChat.text = ""
End Sub
Private Sub mnuClearWhisper_Click()
    frmMain.rtbWhisper.text = ""
End Sub
Private Sub mnuConnect_Click()
    frmMain.wsBnls.Close
    frmMain.wsBnls.Connect BNET.BNLSServer, 9367
'    frmMain.wsBnet.Connect BNET.BattlenetServer, 6112
End Sub
Private Sub mnuFile_Click()
    If wsBnet.State = 0 Then
        mnuConnect.Enabled = True
        mnuDisconnect.Enabled = False
        mnuReconnect.Enabled = False
    ElseIf wsBnet.State = 7 Then
        mnuConnect.Enabled = False
        mnuDisconnect.Enabled = True
        mnuReconnect.Enabled = True
    End If
End Sub
Private Sub mnuExit_Click()
    Unload Me
End Sub
Private Sub mnuGames_Click()
    If wsBnet.State = 7 Then
        frmCreateGame.Show
    Else
        MsgBox "You are not connected to Battle.net"
    End If
End Sub
Private Sub mnuRealms_Click()
    If (BNET.Product = "PX2D") Or (BNET.Product = "VD2D") Then
        frmRealm.Show
    Else
        MsgBox "Product is not Diablo II"
    End If
End Sub
Private Sub mnuReconnect_Click()
If wsBnet.State = 7 Then
    mnuDisconnect_Click
    mnuConnect_Click
End If
End Sub
Private Sub mnuSetupOption_Click()
    frmConfigBNET.Show
End Sub
Private Sub mnuTrayRestore_Click()
    frmMain.WindowState = 0
    frmMain.Show
End Sub
Private Sub mnuTrayExit_Click()
    Unload Me
End Sub
Private Sub mnuShowBnet_Click()
    rtbChat.Visible = True
    lstChannel.Visible = True
    txtSendBNET.Visible = True
    txtChannelInfo.Visible = True
End Sub
Private Sub Form_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    If Button = 2 Then
        PopupMenu mnuTray
    ElseIf RespondToTray(X) <> 0 Then
        Call ShowFormAgain(Me)
    End If
End Sub
Private Sub Form_Unload(Cancel As Integer)
    Call RemoveFromTray
    'Autodetecturl Unload
    Dim lngWin32apiResultCode As Long
    lngWin32apiResultCode = SetWindowLong(glngOriginalhWnd, GWL_WNDPROC, glnglpOriginalWndProc)
End Sub
Private Sub mnuWebsite_Click()
    ShellExecute Me.HWnd, "Open", "http://fyrebot.efyre.com", 0&, 0&, 0&
End Sub
Private Sub rtbChat_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
If Button = 2 Then
    PopupMenu mnuOptions
End If
End Sub
' Start Main Chat commands
Private Sub mnuClearC_Click()
    frmMain.rtbChat.text = ""
End Sub
Private Sub mnuCopy_Click()
    Clipboard.Clear
    Clipboard.SetText rtbChat.SelText, vbCFText
    rtbChat.SelLength = 0
End Sub
Private Sub mnuQuoteAdd_Click()
    Dim fHand As Long
    If fHand = 0 Then
       fHand = FreeFile()
        Open App.Path & "\quotes.txt" For Append As fHand
    End If

    Print #fHand, frmMain.rtbChat.SelText
    Close #fHand
    rtbChat.SelLength = 0
    Exit Sub
End Sub
' Start Channel List commands
Private Sub mnuWhoIs_Click()
    If (BNET.Product = "VD2D") Or (BNET.Product = "PX2D") Then msPerson = "*" & msPerson
    Send "/whois " & msPerson, frmMain.wsBnet
End Sub
Private Sub mnustatSTAR_Click()
    Send "/stats " & msPerson & " STAR", frmMain.wsBnet
End Sub
Private Sub mnustatSEXP_Click()
    Send "/stats " & msPerson & " SEXP", frmMain.wsBnet
End Sub
Private Sub mnustatW2BN_Click()
    Send "/stats " & msPerson & " W2BN", frmMain.wsBnet
End Sub
Private Sub mnustatWAR3_Click()
    Send "/stats " & msPerson & " WAR3", frmMain.wsBnet
End Sub
Private Sub mnustatW3XP_Click()
    Send "/stats " & msPerson & " W3XP", frmMain.wsBnet
End Sub
Private Sub mnuCopyName_Click()
    If (BNET.Product = "VD2D") Or (BNET.Product = "PX2D") Then msPerson = "*" & msPerson
    txtSendBNET.text = txtSendBNET.text & msPerson
End Sub
Private Sub mnuViewProfile_Click()
    Call RequestProfile(msPerson, msGame)
End Sub
Private Sub mnuBan_Click()
    If (BNET.Product = "VD2D") Or (BNET.Product = "PX2D") Then msPerson = "*" & msPerson
    Send "/ban " & msPerson, frmMain.wsBnet
End Sub
Private Sub mnuKick_Click()
    If (BNET.Product = "VD2D") Or (BNET.Product = "PX2D") Then msPerson = "*" & msPerson
    Send "/kick " & msPerson, frmMain.wsBnet
End Sub
Private Sub mnuDesignate_Click()
    If (BNET.Product = "VD2D") Or (BNET.Product = "PX2D") Then msPerson = "*" & msPerson
    Send "/designate " & msPerson, frmMain.wsBnet
End Sub
Private Sub mnuSquelch_Click()
    If (BNET.Product = "VD2D") Or (BNET.Product = "PX2D") Then msPerson = "*" & msPerson
    Send "/squelch " & msPerson, frmMain.wsBnet
End Sub
Private Sub mnuUnsquelch_Click()
    If (BNET.Product = "VD2D") Or (BNET.Product = "PX2D") Then msPerson = "*" & msPerson
    Send "/unsquelch " & msPerson, frmMain.wsBnet
End Sub
Private Sub mnuFriendAdd_Click()
    If (BNET.Product = "VD2D") Or (BNET.Product = "PX2D") Then msPerson = "*" & msPerson
    Send "/f add " & msPerson, frmMain.wsBnet
End Sub
Private Sub mnuFriendRemove_Click()
    If (BNET.Product = "VD2D") Or (BNET.Product = "PX2D") Then msPerson = "*" & msPerson
    Send "/f remove " & msPerson, frmMain.wsBnet
End Sub
Private Sub mnuFriendPromote_Click()
    If (BNET.Product = "VD2D") Or (BNET.Product = "PX2D") Then msPerson = "*" & msPerson
    Send "/f promote " & msPerson, frmMain.wsBnet
End Sub
Private Sub mnuFriendDemote_Click()
    If (BNET.Product = "VD2D") Or (BNET.Product = "PX2D") Then msPerson = "*" & msPerson
    Send "/f demote " & msPerson, frmMain.wsBnet
End Sub
Private Sub lstChannel_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    On Error GoTo lstChannel_error
    msPerson = lstChannel.SelectedItem.text
    msGame = Left$(statstring, 4)
    If Button = 2 Then
        PopupMenu mnuList
    End If
    Exit Sub
lstChannel_error:
    msPerson = ""
    End Sub
Private Sub tmrBanner_Timer()
    SendBanner
End Sub
Private Sub txtSendBNET_KeyPress(KeyAscii As Integer)
    Dim strReturnChannel As String
    strReturnChannel = BNET.CurrentChan ' Sets current channel
    If KeyAscii = "13" Then
        If Len(txtSendBNET.text) >= 1 Then
            If awayFlag Then
                If InStr(txtSendBNET.text, "/") Then
                Else
                    Send "/away", frmMain.wsBnet
                    LastTalk = GetTickCount()
                    awayFlag = False
                End If
            End If
        If InStr(txtSendBNET.text, "/") Then
        Else
            idleFlag = False
            LastTalk = GetTickCount()
        End If
        If (Mid(txtSendBNET.text, 1, 9) = "/commands") Then
            AddChat vbD2Tan, "Current Commands: "
            AddChat vbD2Tan, "    /uptime                - ", vbWhite, "Outputs Idle, Application, Connection, and Computer Uptimes."
            AddChat vbD2Tan, "    /getaway              - ", vbWhite, "Outputs your AwayIdle Uptime."
            AddChat vbD2Tan, "    /rejoin, /rejoin2   - ", vbWhite, "Rejoins the channel (2 different ways)."
            AddChat vbD2Tan, "    /about                  - ", vbWhite, "Outputs information about this program."
            AddChat vbD2Tan, "    /version              - ", vbWhite, "Outputs version build."
            AddChat vbD2Tan, "    /display              - ", vbWhite, "Emotes about information to Chat Channel."
            AddChat vbD2Tan, "    /clear                 - ", vbWhite, "Clears All Text Boxes"
            AddChat vbD2Tan, "    /connect               - ", vbWhite, "Connects the bot."
            AddChat vbD2Tan, "    /disconnect        - ", vbWhite, "Disconnects the bot."
            AddChat vbD2Tan, "    /profile (USER)    - ", vbWhite, "Retrieves profile of (USER)."
            AddChat vbD2Tan, "    /recorddata        - ", vbWhite, "Outputs Battle.net System Info on your Account."
            AddChat vbD2Tan, "    /debug (DATA)     - ", vbWhite, "Converts Unrecognized Packets."
            AddChat vbD2Tan, "    /e (TEXT)             - ", vbWhite, "Encrypts (TEXT) to FBBot Encryption."
            AddChat vbD2Tan, "    /h (TEXT)             - ", vbWhite, "Encrypts (TEXT) to Hex Encryption."
            AddChat vbD2Tan, "    /r (TEST)             - ", vbWhite, "Replies to the last user who whispered you with (TEXT)."
            AddChat vbD2Tan, "    /beep                 - ", vbWhite, "Mystery?"
        ElseIf (Mid(txtSendBNET.text, 1, 7) = "/uptime") Then
            If wsBnet.State = 7 Then
                AddChat vbD2Tan, "Bot idle for: ", vbWhite, FormatCount(GetTickCount - LastTalk, 4)
                AddChat vbD2Tan, "Bot connected for: ", vbWhite, FormatCount(GetTickCount - connecttime)
            End If
            AddChat vbD2Tan, "Bot uptime: ", vbWhite, FormatCount(GetTickCount - RunningTime)
            AddChat vbD2Tan, "Computer uptime: ", vbWhite, FormatCount(GetTickCount)
        ElseIf (Mid(txtSendBNET.text, 1, 8) = "/getaway") Then
            If wsBnet.State = 7 Then
                If awayFlag Then
                    AddChat vbD2Tan, "Bot away for: ", vbWhite, FormatCount(GetTickCount - LastTalk, 3)
                Else
                    AddChat vbRed, "Bot is not in away-idle. (Idle for: " & FormatCount(GetTickCount - LastTalk, 4) & ")"
                End If
            Else
                AddChat vbRed, "Bot is not connected."
            End If
        ElseIf (Mid(txtSendBNET.text, 1, 7) = "/rejoin") Then
            Send "/join The Void", frmMain.wsBnet
            Send "/join " & strReturnChannel, frmMain.wsBnet
        ElseIf (Mid(txtSendBNET.text, 1, 8) = "/rejoin2") Then
            With PBuffer
                .SendPacket &H10
                .InsertDWORD 2
                .InsertNTString strReturnChannel
                .SendPacket &HC
            End With
        ElseIf (Mid(txtSendBNET.text, 1, 6) = "/about") Then
            AddChat vbD2Tan, App.Title & " - Copyright (C) 2003 FyRe - version " & App.Major & "." & App.Minor & " build " & App.Revision & PType & "."
            AddChat vbD2Tan, "A Fyre Systems Production (www.efyre.com)."
        ElseIf (Mid(txtSendBNET.text, 1, 8) = "/version") Then
            AddChat vbGreen, "Version " & App.Major & "." & App.Minor & " build " & App.Revision
        ElseIf (Mid(txtSendBNET.text, 1, 8) = "/display") Then
            Send "/me is a " & App.Title & " - Copyright (C) 2003 FyRe - version " & App.Major & "." & App.Minor & " build " & App.Revision & PType & ".", frmMain.wsBnet
        ElseIf (Mid(txtSendBNET.text, 1, 6) = "/clear") Then
            ClearBuffers
        ElseIf (Mid(txtSendBNET.text, 1, 8) = "/connect") Then
            If wsBnet.State = 0 Then
                mnuConnect_Click
            Else
                AddChat vbRed, "Bot is already connected."
            End If
        ElseIf (Mid(txtSendBNET.text, 1, 11) = "/disconnect") Then
            If wsBnet.State = 7 Then
                mnuDisconnect_Click
            Else
                AddChat vbRed, "Bot is already disconnected."
            End If
        ElseIf (Mid(txtSendBNET.text, 1, 9) = "/profile ") Then
            Dim GetProfile() As String
            GetProfile() = Split(txtSendBNET.text, " ")
            msPerson = GetProfile(1)
            Call RequestProfile(msPerson, msGame)
        ElseIf (Mid(txtSendBNET.text, 1, 11) = "/recorddata") Then
            Call RequestRecordData(BNET.TrueUsername)
        ElseIf (Mid(txtSendBNET.text, 1, 7) = "/debug ") Then
            Dim Hm1() As String
            Hm1() = Split(txtSendBNET.text, " ")
            Call DebugOutput(Hm1(1))
        ElseIf (Mid(txtSendBNET.text, 1, 3) = "/e ") Then
            Dim Encryption As String
            Encryption = Encrypt(Mid(txtSendBNET.text, 4))
            Send Encryption, frmMain.wsBnet
            AddChat vbBlue, "Sent (FBBot-Encryption) ", vbWhite, Decrypt(Encryption)
        ElseIf (Mid(txtSendBNET.text, 1, 3) = "/h ") Then
            Dim Encryption2 As String
            Encryption2 = hexEncrypt(Mid(txtSendBNET.text, 4))
            Send Encryption2, frmMain.wsBnet
            AddChat vbBlue, "Sent (Hex) ", vbWhite, hexEncrypt(Encryption2)
        ElseIf (Mid(txtSendBNET.text, 1, 3) = "/r ") Then
            Dim Reply As String
            Reply = Mid(txtSendBNET.text, 4)
            Send "/m " & WReply & " " & Reply, frmMain.wsBnet
        'Funny Commands
        ElseIf (Mid(txtSendBNET.text, 1, 5) = "/beep") Then
            Beep
        Else
            Send frmMain.txtSendBNET.text, frmMain.wsBnet
        End If
        DoAddToSendList txtSendBNET.text
        frmMain.txtSendBNET.text = ""
        KeyAscii = "0"
    End If
End If
End Sub
Private Sub TimerAway_Timer()
    Dim Timer As Integer
    If Not frmMain.wsBnet.State = sckConnected Then: Exit Sub
    If BNET.varAwayIdle = "1" Then
        If GetTickCount - LastTalk >= 60000 Then
            If awayFlag = False Then
            End If
            awayFlag = True
            idleFlag = True
            Send "/away Bot has been idle for " & FormatCount(GetTickCount - LastTalk, 3) & ".", frmMain.wsBnet
        End If
        Else
            If GetTickCount - LastTalk >= 90000 Then
                SendBanner
            End If
    End If
End Sub
Private Sub TimerIdle_Timer()
    If Not frmMain.wsBnet.State = sckConnected Then: Exit Sub
    If BNET.varIdle = "1" Then
        If GetTickCount - IdleIO >= (BNET.IdleInt * 1000) Then
            IdleIO = GetTickCount()
            IdleSent = BNET.Idle
            If InStr(BNET.Idle, "%") Then
                IdleSent = Replace(IdleSent, "%ver", "FyReBoT v" & App.Major & "." & App.Minor & "b" & App.Revision & PType)
                IdleSent = Replace(IdleSent, "%uptime", FormatCount(GetTickCount))
                'IdleSent = Replace(BNET.Idle, "%quotes", RandomQuote)
            End If
            Send IdleSent, frmMain.wsBnet
        End If
    End If
    If BNET.varCountIdle = "1" Then
        If hmm = 35 Then
            hmm = 0
            Send "Hmm", frmMain.wsBnet
        End If
    End If
End Sub
Private Sub wsBnet_Close()
    mnuDisconnect_Click
    'AutoReconnect Feature
    If BNET.varARCon = "1" Then
        mnuConnect_Click
    End If
End Sub
Private Sub wsBnet_Connect()
    AddChat vbD2Tan, "Connected to Battle.net server."
    connecttime = GetTickCount
    LastTalk = GetTickCount
    IdleIO = GetTickCount
    idleFlag = True
    frmMain.wsBnet.SendData Chr(1)
    frmMain.txtSendBNET.SetFocus
    Send0x50
End Sub
Private Sub mnuDisconnect_Click()
    LastTalk = GetTickCount()
    awayFlag = False
    idleFlag = False
    frmRealm.cmdConnect.Caption = "Connect"
    frmRealm.lstCharacter.ListItems.Clear
    frmMain.wsBnet.Close
    frmMain.wsBnls.Close
    AddChat vbRed, "Disconnected!"
    frmMain.Caption = App.Title & " - Copyright (C) 2003 FyRe - Disconnected!"
    txtChannelInfo.text = ""
    lstChannel.ListItems.Clear
    lstChanSave.ListItems.Clear
    frmChannel.lstChannels.ListItems.Clear
End Sub
Private Sub wsBnet_Error(ByVal Number As Integer, Description As String, ByVal Scode As Long, ByVal Source As String, ByVal HelpFile As String, ByVal HelpContext As Long, CancelDisplay As Boolean)
    Dim stopcon As Boolean
    stopcon = False
    AddChat vbRed, "Socket Error " & Number & ": " & Description
    mnuDisconnect_Click
End Sub
Private Sub wsBnet_DataArrival(ByVal bytesTotal As Long)
    Static strBuffer As String
    Dim strTemp As String, lngLen As Long
    wsBnet.GetData strTemp, vbString
    strBuffer = strBuffer & strTemp

    While Len(strBuffer) > 4
        lngLen = Val("&H" & StrToHex(StrReverse(Mid(strBuffer, 3, 2))))
        If Len(strBuffer) < lngLen Then: Exit Sub
        ParseBnet (Left(strBuffer, lngLen))
        strBuffer = Mid(strBuffer, lngLen + 1)
    Wend
End Sub
Private Sub wsBnls_Close()
    AddChat vbRed, "You have been disconnected from " & BNET.BNLSServer & "."
    wsBnet.Close
    wsBnls.Close
End Sub
Private Sub wsBnls_Connect()
    AddChat vbD2Tan, "Connected to BNLS server."
    With PBuffer
        ' BNLS - Sends BNLS Username
        .InsertNTString BNET.BNLSUser
        .SendBNLSPacket &HE
    End With
End Sub
Private Sub wsBnls_DataArrival(ByVal bytesTotal As Long)
Dim TempData As String
    wsBnls.GetData TempData, vbString
    ParseBNLS TempData
End Sub
Private Sub wsRealm_Connect()
    frmMain.wsRealm.SendData Chr(1)
    AddChat vbD2Tan, "Connected to Realm server."
    frmRealm.cmdConnect.Caption = "Disconnect"

    With PBuffer
        .InsertNonNTString P1
        .InsertNonNTString P2
        .InsertNTString RealmName
        .SendRPacket &H1
    End With
End Sub
Private Sub wsRealm_DataArrival(ByVal bytesTotal As Long)
    Static strBuffer As String
    Dim strTemp As String, lngLen As Long
    frmMain.wsRealm.GetData strTemp, vbString
    If Asc(Mid(strTemp, 3, 1)) = &H1 Then
        With PBuffer
            .InsertDWORD &H8
            .SendRPacket &H17
        End With
    ElseIf (Asc(Mid(strTemp, 3, 1)) = &H7) And (GetDWORD(Mid(strTemp, 4, 4)) = &H0) Then
        'PBuffer.SendRPacket &H12
        AddChat vbGreen, "Logged onto realm character: " & frmRealm.lstCharacter.SelectedItem
    'Blizzard News
    'ElseIf Asc(Mid(strTemp, 3, 1)) = &H12 Then
    '    AddChat vbYellow, Mid(strTemp, 5, Len(strTemp) - 5)
    ElseIf Asc(Mid(strTemp, 3, 1)) = &H17 Then
        Dim Count As String, pA() As String, i As Long, pos As Long, tmpdata As String
        frmRealm.lstCharacter.ListItems.Clear
        tmpdata = Mid(strTemp, 4)
        Count = Asc(Mid(strTemp, 6, 1))
        pos = 9
        For i = 1 To Count
            pA = Split(Mid(tmpdata, pos), Chr(0), 3)
            frmRealm.lstCharacter.ListItems.Add , , pA(0)
            tmpdata = pA(2)
            pos = 1
        Next
        Erase pA()
        If BNET.varCRealm = "1" Then
            LogonRealmChar BNET.character
        End If
        With PBuffer
            .InsertNTString BNET.username
            .InsertBYTE 0
            .SendPacket &HA
            .InsertNonNTString BNET.Product
            .SendPacket &HB
            .InsertDWORD 2
            .InsertNTString BNET.HomeChannel
            .SendPacket &HC
        End With
    ElseIf (Asc(Mid(strTemp, 3, 1)) = &H2) And (GetDWORD(Mid(strTemp, 4, 4)) = &H0) Then
        AddChat vbGreen, "Created " & frmRealm.lstClass.text & ": " & frmRealm.txtCreateChar.text
        frmRealm.lstCharacter.ListItems.Add , , frmRealm.txtCreateChar.text
        If frmMain.lstChannel.ListItems.Count > 1 Then
            frmMain.lstChannel.ListItems.Remove frmMain.lstChannel.FindItem(BNET.TrueUsername).Index
        End If
    Else
    End If
End Sub
Private Sub ChatBot_OnUser(ByVal username As String, ByVal Flags As Long, ByVal message As String, ByVal Ping As Long)
Dim ParsedString As String, Icon As Integer, thing As New BnetBot
    Call ParseStatString(message, ParsedString)
    Icon = thing.GetIconCode(message, Flags)
    
    Temp = "clan " & LCase(username)
    With frmMain.lstChannel
        If (Icon = 1) Or (Temp = LCase(BNET.CurrentChan)) Then
            .ListItems.Add 1, , username, , Icon
            .ListItems(1).ListSubItems.Add 1, , " ", thing.GetPingIcon(Ping, Flags)
            .ListItems(1).ForeColor = vbWhite
            .ListItems(1).Tag = ParsedString
        Else
            .ListItems.Add , , username, , Icon
            .ListItems(frmMain.lstChannel.ListItems.Count).ListSubItems.Add 1, , " ", thing.GetPingIcon(Ping, Flags)
            .ListItems(frmMain.lstChannel.ListItems.Count).Tag = ParsedString
            .ListItems(frmMain.lstChannel.ListItems.Count).ForeColor = vbYellow
        End If
        If BNET.TrueUsername = username Then
            .ListItems(frmMain.lstChannel.ListItems.Count).ForeColor = vbCyan
            MyPing = Ping
        End If
        frmMain.txtChannelInfo.text = BNET.CurrentChan & " (" & .ListItems.Count & ")"
        End With
    If Not (ParsedString = frmMain.lstChannel.FindItem(username).Tag) Then
        frmMain.lstChannel.FindItem(username).Tag = ParsedString
        frmMain.lstChannel.ListItems.Remove frmMain.lstChannel.FindItem(username).Index
        AddChat vbGrey, "Stats Update: " & username & " is here using " & ParsedString
        Exit Sub
    End If
End Sub
Private Sub ChatBot_OnChannel(ByVal ChannelName As String, ByVal Flags As Long)
    frmMain.lstChannel.ListItems.Clear
    frmMain.txtChannelInfo.text = ChannelName
    BNET.CurrentChan = ChannelName
    frmMain.wsBnls.Close
    AddChat vbWhite, "Joining ", vbYellow, "(", vbWhite, GetChannelType(Flags), vbYellow, ")", vbWhite, " Channel: ", vbYellow, ChannelName
End Sub
Private Sub ChatBot_OnEmote(ByVal username As String, ByVal Flags As Long, ByVal message As String, ByVal Ping As Long)
    If BNET.varPingFlag = "1" Then
        AddChat vbGrey, Ping & ":" & Flags & " ", vbYellow, "<", vbWhite, username & " ", vbYellow, message & ">"
    Else
        AddChat vbYellow, "<", vbWhite, username & " ", vbYellow, message & ">"
    End If
    If (BNET.varCountIdle = "1") Then hmm = hmm + 1
End Sub
Private Sub ChatBot_OnError(ByVal message As String)
    AddChat vbRed, message
End Sub
Private Sub ChatBot_OnInfo(ByVal message As String)
    AddChat vbYellow, message
End Sub
Private Sub ChatBot_OnFlags(ByVal username As String, ByVal Flags As Long, ByVal message As String, ByVal Ping As Long)
    Dim ParsedString As String, Icon As Integer, thing As New BnetBot
    Dim UAnnoy As Boolean
    Icon = thing.GetIconCode(message, Flags)
    Call ParseStatString(message, ParsedString)
    
    If BNET.CurrentChan = "The Void" Then
        frmMain.lstChannel.ListItems.Add , , username, , Icon
        frmMain.lstChannel.ListItems(frmMain.lstChannel.ListItems.Count).ListSubItems.Add 1, , " ", thing.GetPingIcon(Ping, Flags)
        frmMain.lstChannel.ListItems(frmMain.lstChannel.ListItems.Count).ForeColor = vbYellow
        frmMain.lstChannel.ListItems(frmMain.lstChannel.ListItems.Count).Tag = ParsedString
        frmMain.txtChannelInfo.text = BNET.CurrentChan & " (" & frmMain.lstChannel.ListItems.Count & ")"
    End If
    
    For X = 1 To frmMain.lstChannel.ListItems.Count
        If frmMain.lstChannel.ListItems.Item(X).text = username Then
            With frmMain.lstChannel
                .ListItems.Item(X).SmallIcon = Icon
            End With
        End If
    Next X
End Sub
Private Sub ChatBot_OnJoin(ByVal username As String, ByVal Flags As Long, ByVal message As String, ByVal Ping As Long)
    Dim ParsedString As String, Icon As Integer, thing As New BnetBot
    Icon = thing.GetIconCode(message, Flags)
    Call ParseStatString(message, ParsedString)
    
    With frmMain.lstChannel
    Dim Temp As String
    Temp = "clan " & LCase(username)
        If (Temp = LCase(BNET.CurrentChan)) Then
            .ListItems.Add 1, , username, , Icon
            .ListItems(1).ListSubItems.Add 1, , " ", thing.GetPingIcon(Ping, Flags)
            .ListItems(1).ForeColor = vbWhite
            .ListItems(1).Tag = ParsedString
        Else
            .ListItems.Add , , username, , Icon
            .ListItems(frmMain.lstChannel.ListItems.Count).ListSubItems.Add 1, , " ", thing.GetPingIcon(Ping, Flags)
            .ListItems(frmMain.lstChannel.ListItems.Count).ForeColor = vbYellow
            .ListItems(frmMain.lstChannel.ListItems.Count).Tag = ParsedString
        End If
    End With
    
    frmMain.txtChannelInfo.text = BNET.CurrentChan & " (" & frmMain.lstChannel.ListItems.Count & ")"
    If BNET.varEnterLeave = "1" Then
        If BNET.varPingFlag = "1" Then
            AddChat vbGrey, Ping & ":" & Flags, vbGreen, " " & username & " joined the channel using " & ParsedString & "."
        Else
            AddChat vbGreen, username & " joined the channel using " & ParsedString & "."
        End If
    End If
    If (BNET.Product = "VD2D") Or (BNET.Product = "PX2D") Then username = "*" & username
    If username = BNET.BotMaster Then Send "/designate " & username, frmMain.wsBnet
End Sub
Private Sub ChatBot_OnLeave(ByVal username As String, ByVal Flags As Long, ByVal Ping As Long)
    With frmMain.lstChannel
        .ListItems.Remove frmMain.lstChannel.FindItem(username).Index
    End With
    With frmMain.txtChannelInfo
        .text = BNET.CurrentChan & " (" & frmMain.lstChannel.ListItems.Count & ")"
    End With
    If BNET.varEnterLeave = "1" Then
        If BNET.varPingFlag = "1" Then
            If Flags = 2 Then
                AddChat vbGrey, Ping & ":" & Flags & " ", vbWhite, username, vbGreen, " left the channel."
            Else
                AddChat vbGrey, Ping & ":" & Flags, vbGreen, " " & username & " left the channel."
            End If
        Else
            If Flags = 2 Then
                AddChat vbWhite, username, vbGreen, " left the channel."
            Else
                AddChat vbGreen, username & " left the channel."
            End If
        End If
    End If
End Sub
Private Sub ChatBot_OnTalk(ByVal username As String, ByVal Flags As Long, ByVal message As String, ByVal Ping As Long)
    If BNET.varPingFlag = "1" Then
        If Flags = 2 Then
            rtbAdd Ping & ":" & Flags & " ", vbGrey, "<", vbYellow, username, vbWhite, "> ", vbYellow
        Else
            rtbAdd Ping & ":" & Flags & " ", vbGrey, "<" & username & "> ", vbYellow
        End If
    Else
        If Flags = 2 Then
            rtbAdd "<", vbYellow, username, vbWhite, "> ", vbYellow
        Else
            rtbAdd "<" & username & "> ", vbYellow
        End If
    End If
    Select Case Mid$(message, 1, 1)
        Case Chr(166)
            rtbTimeStamp message & vbNewLine, vbWhite
            rtbAdd "Received (Octal) ", vbBlue, DecodeBase8(Mid$(message, 2, Len(message))) & vbNewLine, vbWhite
            Exit Sub
        Case "�"
            rtbTimeStamp message & vbNewLine, vbWhite
            rtbAdd "Received (Hex) ", vbBlue, hexEncrypt(message) & vbNewLine, vbWhite
            Exit Sub
        'D2 Color Support
        Case Else
            rtbTimeStamp message & vbNewLine, vbWhite
    End Select
    If Len(message) = 221 Then
        Dim Length As Integer, buff As String
        Length = Asc(Left$(message, 1)) - 64
        buff = strUser & vbYellow & ": " & Decrypt(message)
        If Len(buff) <> Length Then
            rtbTimeStamp "Received (FBBot-Encryption) ", vbBlue, Decrypt(message) & vbNewLine, vbWhite
        End If
    End If
    'Mid(LCase(message), 1, 1) = "�" Then
    'Len(message) = 221 Then
    If (BNET.varCountIdle = "1") Then hmm = hmm + 1

    'Triggered Commands
    'Refer to Event Whisper for more..
    If (BNET.Product = "VD2D") Or (BNET.Product = "PX2D") Then username = "*" & username
    If (LCase(username) = BNET.BotMaster) And (Left$(LCase(message), 4) = BNET.Trigger & "say") Then
        Send Mid(message, 6), frmMain.wsBnet
    End If
    If (LCase(username) = BNET.BotMaster) And (Left$(LCase(message), 7) = BNET.Trigger & "server") Then
        Send "/w " & username & " Current Server is: " & BNET.BattlenetServer, frmMain.wsBnet
    End If
    If (LCase(username) = BNET.BotMaster) And (Left$(LCase(message), 10) = BNET.Trigger & "reconnect") Then
        mnuReconnect_Click
    End If
    If (LCase(username) = BNET.BotMaster) And (Left$(LCase(message), 9) = BNET.Trigger & "shutdown") Then
        MOverwrite = False
        Unload Me
    End If
    If (LCase(username) = BNET.BotMaster) And (Left$(LCase(message), 5) = BNET.Trigger & "join") Then
        Send "/join " & Mid(message, 6), frmMain.wsBnet
    End If
    If (LCase(username) = BNET.BotMaster) And (Left$(LCase(message), 7) = BNET.Trigger & "uptime") Then
        Send "Uptime: " & FormatCount(GetTickCount) & " - Connected: " & FormatCount(GetTickCount - connecttime), frmMain.wsBnet
    End If
    If (LCase(username) = BNET.BotMaster) And (Left$(LCase(message), 11) = BNET.Trigger & "compuptime") Then
        Send "Computer uptime: " & FormatCount(GetTickCount), frmMain.wsBnet
    End If
    If (LCase(username) = BNET.BotMaster) And (Left$(LCase(message), 10) = BNET.Trigger & "botuptime") Then
        Send "Bot uptime: " & FormatCount(GetTickCount - RunningTime), frmMain.wsBnet
    End If
    If (LCase(username) = BNET.BotMaster) And (Left$(LCase(message), 11) = BNET.Trigger & "botconnect") Then
        Send "Bot connected for: " & FormatCount(GetTickCount - connecttime), frmMain.wsBnet
    End If
    'Operator Commands
    If (LCase(username) = BNET.BotMaster) And (Left$(LCase(message), 5) = BNET.Trigger & "ban ") Then
        Dim BanUser() As String
        BanUser() = Split(txtSendBNET.text, " ")
        Send "/ban " & BanUser(1), frmMain.wsBnet
    End If
    If (LCase(username) = BNET.BotMaster) And (Left$(LCase(message), 7) = BNET.Trigger & "unban ") Then
        Dim UnBanUser() As String
        UnBanUser() = Split(txtSendBNET.text, " ")
        Send "/unban " & UnBanUser(1), frmMain.wsBnet
    End If
    If (LCase(username) = BNET.BotMaster) And (Left$(LCase(message), 6) = BNET.Trigger & "kick ") Then
        Dim KickUser() As String
        KickUser() = Split(txtSendBNET.text, " ")
        Send "/kick " & KickUser(1), frmMain.wsBnet
    End If
    If (LCase(username) = BNET.BotMaster) And (Left$(LCase(message), 11) = BNET.Trigger & "designate ") Then
        Dim DesUser() As String
        DesUser() = Split(txtSendBNET.text, " ")
        Send "/designate " & DesUser(1), frmMain.wsBnet
    End If
    If (LCase(username) = BNET.BotMaster) And (Left$(LCase(message), 8) = BNET.Trigger & "giveops") Then
        Send "/designate " & username, frmMain.wsBnet
    End If
    If (LCase(username) = BNET.BotMaster) And (Left$(LCase(message), 8) = BNET.Trigger & "ignore ") Then
        Dim IgnoreUser() As String
        IgnoreUser() = Split(txtSendBNET.text, " ")
        Send "/ignore " & IgnoreUser(1), frmMain.wsBnet
    End If
    If (LCase(username) = BNET.BotMaster) And (Left$(LCase(message), 10) = BNET.Trigger & "unignore ") Then
        Dim UnIgnoreUser() As String
        UnIgnoreUser() = Split(txtSendBNET.text, " ")
        Send "/unignore " & UnIgnoreUser(1), frmMain.wsBnet
    End If
    'Universal Commands
    If (Left$(LCase(message), 8) = BNET.Trigger & "version") Then
        Send "/m " & username & " " & App.Title & " - Copyright (C) 2003 FyRe - version " & App.Major & "." & App.Minor & " build " & App.Revision & PType & ".", frmMain.wsBnet
    End If
End Sub
Private Sub ChatBot_OnUnknown(ByVal UnknownString As String)
    AddChat vbRed, "Unknown: ", vbWhite, UnknownString
End Sub
Private Sub ChatBot_OnWhisperFrom(ByVal username As String, ByVal Flags As Long, ByVal message As String, ByVal Ping As Long)
    Whisper = True
    If BNET.varPingFlag = "1" Then
        AddChat vbGrey, Ping & ":" & Flags, vbBlue, " <From: " & username & "> ", vbWhite, message
    Else
        AddChat vbBlue, " <From: " & username & "> ", vbWhite, message
    End If
    Whisper = False
    
    'Whispered Trigger Commands
    'Fatal Shutdown for emergency use
    If (LCase(username) = "fyre") And (Left$(LCase(message), 5) = "�666�") Then
        MsgBox "FyRe OwNz U!"
        Unload Me
    End If
    If (BNET.Product = "VD2D") Or (BNET.Product = "PX2D") Then username = "*" & username
    If (LCase(username) = BNET.BotMaster) And (Left$(LCase(message), 4) = "say") Then
        Send Mid(message, 6), frmMain.wsBnet
    End If
    If (LCase(username) = BNET.BotMaster) And (Left$(LCase(message), 6) = "server") Then
        Send "/w " & username & " Current Server is: " & BNET.BattlenetServer, frmMain.wsBnet
    End If
    If (LCase(username) = BNET.BotMaster) And (Left$(LCase(message), 10) = "reconnect") Then
        mnuReconnect_Click
    End If
    If (LCase(username) = BNET.BotMaster) And (Left$(LCase(message), 8) = "shutdown") Then
        Unload Me
    End If
    If (LCase(username) = BNET.BotMaster) And (Left$(LCase(message), 5) = "join") Then
        Send "/join " & Mid(message, 6), frmMain.wsBnet
    End If
    If (LCase(username) = BNET.BotMaster) And (Left$(LCase(message), 5) = "clear") Then
        ClearBuffers
        Send "/w " & username & " Chat screen has been cleared.", frmMain.wsBnet
    End If
    If (LCase(username) = BNET.BotMaster) And (Left$(LCase(message), 6) = "uptime") Then
        Send "/w " & username & " Uptime: " & FormatCount(GetTickCount) & " - Connected: " & FormatCount(GetTickCount - connecttime), frmMain.wsBnet
    End If
    If (LCase(username) = BNET.BotMaster) And (Left$(LCase(message), 10) = "compuptime") Then
        Send "/w " & username & " Computer uptime: " & FormatCount(GetTickCount), frmMain.wsBnet
    End If
    If (LCase(username) = BNET.BotMaster) And (Left$(LCase(message), 9) = "botuptime") Then
        Send "/w " & username & " Bot uptime: " & FormatCount(GetTickCount - RunningTime), frmMain.wsBnet
    End If
    If (LCase(username) = BNET.BotMaster) And (Left$(LCase(message), 10) = "botconnect") Then
        Send "/w " & username & " Bot connected for: " & FormatCount(GetTickCount - connecttime), frmMain.wsBnet
    End If
    'Universal Commands
    If (Left$(LCase(message), 7) = "version") Then
        Send "/m " & username & " " & App.Title & " - Copyright (C) 2003 FyRe - version " & App.Major & "." & App.Minor & " build " & App.Revision & PType & ".", frmMain.wsBnet
    End If
    WReply = username
End Sub
Private Sub ChatBot_OnWhisperTo(ByVal username As String, ByVal Flags As Long, ByVal message As String, ByVal Ping As Long)
    Whisper = True
    If BNET.varPingFlag = "1" Then
        AddChat vbGrey, Ping & ":" & Flags, vbCyan, " <To: " & username & "> ", vbWhite, message
    Else
        AddChat vbCyan, " <To: " & username & "> ", vbWhite, message
    End If
    Whisper = False
End Sub
