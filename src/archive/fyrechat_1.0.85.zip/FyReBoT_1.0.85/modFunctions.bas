Attribute VB_Name = "modFunctions"
Public Function LoadConfig()
    Dim FullText As String
    BNET.username = GetStuff("BNET", "username")
    BNET.Password = GetStuff("BNET", "password")
    BNET.BattlenetServer = GetStuff("BNET", "server")
    BNET.Product = GetStuff("BNET", "product")
    Call Client(BNET.Product)
    BNET.CDKey = GetStuff("BNET", "cdkey")
     BNET.CDKey = UCase(BNET.CDKey)
    BNET.CDKey2 = GetStuff("BNET", "lod")
     BNET.CDKey2 = UCase(BNET.CDKey2)
    BNET.CdkeyOwner = GetStuff("BNET", "owner")
    'Diablo 2 Options
    BNET.character = GetStuff("BNET", "character")
    BNET.varCRealm = GetStuff("BNET", "autorealm")
    'General Options
    BNET.varAutoCon = GetStuff("BNET", "autoconnect")
    BNET.varPopup = GetStuff("BOT", "popup")
    BNET.varARCon = GetStuff("BNET", "autoreconnect")
    BNET.varLagPlug = GetStuff("BNET", "negativeone")
    BNET.varAdBanner = GetStuff("BNET", "adbanner")
    BNET.varLog = GetStuff("BOT", "logchat")
    BNET.varPingFlag = GetStuff("BOT", "ping:flag")
    'BNLS Options
    BNET.BNLSUser = GetStuff("BNLS", "username")
    BNET.BNLSPass = GetStuff("BNLS", "password")
    BNET.BNLSServer = GetStuff("BNLS", "server")
    'Channel Options
    BNET.BotMaster = GetStuff("BOT", "master")
    BNET.Trigger = GetStuff("BOT", "trigger")
    'BNET.Operator = GetStuff("BOT", "operator")
    BNET.Idle = GetStuff("BOT", "idle")
    BNET.IdleInt = GetStuff("BOT", "idle-interval")
    BNET.HomeChannel = GetStuff("BNET", "home")
    BNET.varEnterLeave = GetStuff("BOT", "joinleave")
    BNET.varAwayIdle = GetStuff("BOT", "away")
    BNET.varCountIdle = GetStuff("BOT", "count-idle")
    BNET.varIdle = GetStuff("BOT", "normal-idle")
    
    If BNET.username = "" Then BNET.username = "Guest"
    If BNET.Password = "" Then BNET.Password = "123456"
    If BNET.Product = "" Then BNET.Product = "RATS"
    If BNET.CdkeyOwner = "" Then BNET.CdkeyOwner = App.Title & " v" & App.Major & "." & App.Minor & "b" & App.Revision
    If BNET.BattlenetServer = "" Then BNET.BattlenetServer = "use-bna-chat01.battle.net"
    If BNET.BNLSUser = "" Then BNET.BNLSUser = "soupbot"
    If BNET.BNLSPass = "" Then BNET.BNLSPass = "s0upb0t"
    If BNET.BNLSServer = "" Then BNET.BNLSServer = "bnls.valhallalegends.com"
    If BNET.Idle = "" Then BNET.Idle = "/me %ver - %uptime"
    If BNET.IdleInt = "" Then BNET.IdleInt = "300"
    
    If BNET.varCRealm = "" Then BNET.varCRealm = 0
    If BNET.varARCon = "" Then BNET.varARCon = 0
    If BNET.varAutoCon = "" Then BNET.varAutoCon = 0
    If BNET.varLagPlug = "" Then BNET.varLagPlug = 0
    If BNET.varAdBanner = "" Then BNET.varAdBanner = 0
    If BNET.varAwayIdle = "" Then BNET.varAwayIdle = 0
    If BNET.varIdle = "" Then BNET.varIdle = 0
    If BNET.varCountIdle = "" Then BNET.varCountIdle = 0
    If BNET.varEnterLeave = "" Then BNET.varEnterLeave = 1
    If BNET.varPopup = "" Then BNET.varPopup = 1
    If BNET.varLog = "" Then BNET.varLog = 0
    If BNET.varPingFlag = "" Then BNET.varPingFlag = 1
End Function
Public Function SaveConfig()
    Dim FullText As String
    Call Client(BNET.Product)
    ' Main Battle.net Save Vars
    If Not WriteStuff("BNET", "username", BNET.username) Then MsgBox "Error"
    If Not WriteStuff("BNET", "password", BNET.Password) Then MsgBox "Error"
    If Not WriteStuff("BNET", "product", BNET.Product) Then MsgBox "Error"
    If Not WriteStuff("BNET", "cdkey", BNET.CDKey) Then MsgBox "Error"
    If Not WriteStuff("BNET", "lod", BNET.CDKey2) Then MsgBox "Error"
    If Not WriteStuff("BNET", "owner", BNET.CdkeyOwner) Then MsgBox "Error"
    If Not WriteStuff("BNET", "server", BNET.BattlenetServer) Then MsgBox "Error"

    'Realm Stuff
    If Not WriteStuff("BNET", "character", BNET.character) Then MsgBox "Error"
    If Not WriteStuff("BNET", "autorealm", BNET.varCRealm) Then MsgBox "Error"
    
    If Not WriteStuff("BNET", "home", BNET.HomeChannel) Then MsgBox "Error"
    If Not WriteStuff("BNET", "autoreconnect", BNET.varARCon) Then MsgBox "Error"
    If Not WriteStuff("BNET", "autoconnect", BNET.varAutoCon) Then MsgBox "Error"
    If Not WriteStuff("BNET", "negativeone", BNET.varLagPlug) Then MsgBox "Error"
    If Not WriteStuff("BNET", "adbanner", BNET.varAdBanner) Then MsgBox "Error"
    
    ' BNLS Save Vars
    If Not WriteStuff("BNLS", "username", BNET.BNLSUser) Then MsgBox "Error"
    If Not WriteStuff("BNLS", "password", BNET.BNLSPass) Then MsgBox "Error"
    If Not WriteStuff("BNLS", "server", BNET.BNLSServer) Then MsgBox "Error"
    
    If Not WriteStuff("BOT", "master", BNET.BotMaster) Then MsgBox "Error"
    If Not WriteStuff("BOT", "trigger", BNET.Trigger) Then MsgBox "Error"
    If Not WriteStuff("BOT", "away", BNET.varAwayIdle) Then MsgBox "Error"
    If Not WriteStuff("BOT", "idle", BNET.Idle) Then MsgBox "Error"
    If Not WriteStuff("BOT", "normal-idle", BNET.varIdle) Then MsgBox "Error"
    If Not WriteStuff("BOT", "count-idle", BNET.varCountIdle) Then MsgBox "Error"
    If Not WriteStuff("BOT", "idle-interval", BNET.IdleInt) Then MsgBox "Error"
    If Not WriteStuff("BOT", "joinleave", BNET.varEnterLeave) Then MsgBox "Error"
    If Not WriteStuff("BOT", "popup", BNET.varPopup) Then MsgBox "Error"
    If Not WriteStuff("BOT", "logchat", BNET.varLog) Then MsgBox "Error"
    If Not WriteStuff("BOT", "ping:flag", BNET.varPingFlag) Then MsgBox "Error"
End Function
Public Function Client(pClient As String)
    If pClient = "RATS" Then
        showClient = "StarCraft"
    ElseIf pClient = "PXES" Then
        showClient = "StarCraft: Brood Wars"
    ElseIf pClient = "VD2D" Then
        showClient = "Diablo II"
    ElseIf pClient = "PX2D" Then
        showClient = "Lord of Destruction"
    ElseIf pClient = "NB2W" Then
        showClient = "WarCraft II"
    ElseIf pClient = "3RAW" Then
        showClient = "WarCraft III"
    Else
        showClient = "StarCraft"
    End If
End Function
Public Function StrToHex(ByVal String1 As String) As String
    Dim strTemp As String, strReturn As String, i As Long
    For i = 1 To Len(String1)
        strTemp = Hex(Asc(Mid(String1, i, 1)))
    If Len(strTemp) = 1 Then strTemp = "0" & strTemp
    strReturn = strReturn & " " & strTemp
    Next i
        StrToHex = strReturn
End Function
Public Function ToHex(Data As String) As String
    Dim i As Integer
    For i = 1 To Len(Data)
        ToHex = ToHex & Right("00" & Hex(Asc(Mid(Data, i, 1))), 2)
    Next i
End Function
Public Function GetWORD(Data As String) As Long
    Dim lReturn As Long
    Call CopyMemory(lReturn, ByVal Data, 2)
    GetWORD = lReturn
End Function
Public Function HexToStr(ByVal Hex1 As String) As String
    Dim strTemp As String, strReturn As String, i As Long
    Hex1 = Replace(Hex1, " ", "")
    If Len(Hex1) Mod 2 <> 0 Then Exit Function
    For i = 1 To Len(Hex1) Step 2
    strReturn = strReturn & Chr(Val("&H" & Mid(Hex1, i, 2)))
    Next i
    HexToStr = strReturn
End Function
Public Sub AddChat(ParamArray saElements() As Variant)
    Dim i As Integer, Data As String
    If awayFlag Then
        If InStr(saElements(i + 1), "as being away") Then Exit Sub
        If InStr(saElements(i + 1), "marked as away") Then Exit Sub
    End If
    rtbTimeStamp "[" & Format(Time, "hh:mm:ss") & "] ", vbWhite
    Data = "[" & Format(Time, "hh:mm:ss") & "] "
    For i = LBound(saElements) To UBound(saElements) Step 2
    If Whisper Then
        With frmMain.rtbWhisper
            .SelStart = Len(.text)
            .SelLength = 0
            .SelColor = saElements(i)
            .SelText = saElements(i + 1) & Left$(vbCrLf, -2 * CLng((i + 1) = UBound(saElements)))
            .SelStart = Len(.text)
        End With
    Else
        With frmMain.rtbChat
            .SelStart = Len(.text)
            .SelLength = 0
            .SelColor = saElements(i)
            .SelText = saElements(i + 1) & Left$(vbCrLf, -2 * CLng((i + 1) = UBound(saElements)))
            .SelStart = Len(.text)
        End With
    End If
    Data = Data & saElements(i + 1)
    Next i
    
    If BNET.varLog = 1 Then Log Data
End Sub
Public Function rtbAdd(ParamArray saElements() As Variant)
    Dim i As Integer
    Dim strTimeStamp As String, Logging As Boolean, Data As String
    If BNET.varLog = "" Then Logging = True
    rtbTimeStamp "[" & Format(Time, "hh:mm:ss") & "] ", vbWhite
    Data = "[" & Format(Time, "hh:mm:ss") & "] "
    For i = LBound(saElements) To UBound(saElements) Step 2
    With frmMain.rtbChat
        .SelStart = Len(.text)
        .SelLength = 0
        .SelColor = saElements(i + 1)
        .SelText = saElements(i) & Left$(vbCrLf, -2 * CLng((i) = UBound(saElements)))
        .SelStart = Len(.text)
    End With
    Data = Data & saElements(i)

    Next i
    If Logging Then Log Data
End Function
Public Sub rtbTimeStamp(ParamArray saElements() As Variant)
    Dim i As Integer
    Dim strTimeStamp As String, Logging As Boolean, Data As String
    If BNET.varLog = "" Then Logging = True
    For i = LBound(saElements) To UBound(saElements) Step 2
    If Whisper Then
    With frmMain.rtbWhisper
        .SelStart = Len(.text)
        .SelLength = 0
        .SelColor = saElements(i + 1)
        .SelText = saElements(i) & Left$(vbCrLf, -2 * CLng((i) = UBound(saElements)))
        .SelStart = Len(.text)
    End With
    Else
    With frmMain.rtbChat
        .SelStart = Len(.text)
        .SelLength = 0
        .SelColor = saElements(i + 1)
        .SelText = saElements(i) & Left$(vbCrLf, -2 * CLng((i) = UBound(saElements)))
        .SelStart = Len(.text)
    End With
    End If
    Data = Data & saElements(i)

    Next i
    If Logging Then Log Data
End Sub
Public Function CheckBuffers()
    If Len(frmMain.rtbChat.text) >= 30000 Then
        frmMain.rtbChat = ""
    Else
    End If
End Function
Public Function KillNull(ByVal text As String) As String
    Dim i As Integer
    i = InStr(1, text, Chr(0))
    If i = 0 Then
        KillNull = text
        Exit Function
    End If
    KillNull = Left(text, i - 1)
End Function
Public Sub Send(ByVal strText As String, Socket As Winsock, Optional Extra As Boolean, Optional ByVal Flags As Long)
    If Not frmMain.wsBnet.State = sckConnected Then Exit Sub
    With PBuffer
        .InsertNTString strText
        .SendPacket &HE
    End With
    If Left(strText, 1) = "/" Then
        Exit Sub
    End If
    Dim Temp As String
    Temp = "clan " & LCase(BNET.TrueUsername)
    If Icon = 11 Or Temp = LCase(BNET.CurrentChan) Then
        MyFlags = 2
    Else
        MyFlags = 0
    End If
    If BNET.varPingFlag = "1" Then
        rtbAdd MyPing & ":" & MyFlags, vbGrey, " <" & BNET.TrueUsername & "> ", vbCyan
    Else
        rtbAdd "<" & BNET.TrueUsername & "> ", vbCyan
    End If
    rtbTimeStamp strText & vbNewLine, vbWhite
End Sub
Public Function WriteStuff(appname As String, key As String, sString As String, Optional strIni As String) As Boolean
    Dim sFile As String
    Dim L As Long
    WriteStuff = False
    On Error GoTo WriteStuff_Error
    If strIni = "" Then
        sFile = App.Path & "\config.ini"
    Else
        sFile = App.Path & "\" & strIni
    End If
    L = WritePrivateProfileString(appname, key, sString, sFile)
    WriteStuff = True

WriteStuff_Error:
    If Err.Number <> 0 Then
        MsgBox Err.Description
    End If
End Function
Public Function GetStuff(appname As String, key As String, Optional strIni As String) As String
    Dim sFile As String
    Dim sDefault As String
    Dim lSize As Integer
    Dim L As Long
    Dim sUser As String
    sUser = Space$(128)
    lSize = Len(sUser)
    If strIni = "" Then
        sFile = App.Path & "\config.ini"
    Else
        sFile = strIni
    End If
    sDefault = ""
    L = GetPrivateProfileString(appname, key, sDefault, sUser, lSize, sFile)
    sUser = Mid(sUser, 1, InStr(sUser, Chr(0)) - 1)
    GetStuff = sUser
End Function
Public Sub Log(Data As String)
    If fHandle = 0 Then
        fHandle = FreeFile()
        Dim tempo As String
        tempo = App.Path
        Call IsPathAFolder(tempo & "/Logs")
        If PathFolder Then
            Open (App.Path & "/Logs/Log(" & Format(Now, "mm-dd-yyyy") & ").txt") For Append As #fHandle
        Else
            Dim blah As SECURITY_ATTRIBUTES
            blah.nLength = LenB(blah)
            Call CreateDirectory(App.Path & "/Logs", blah)
            Open (App.Path & "/Logs/Log(" & Format(Now, "mm-dd-yyyy") & ").txt") For Append As #fHandle
        End If
    End If
    L$ = Len(Data)
    
    'Print #fHandle, Mid(data, 1, L$ - 1)
    Print #fHandle, Data
End Sub
Public Function IsPathAFolder(ByVal sPath As String) As Boolean
   Dim Result As Long
   Result = PathIsDirectory(sPath)
   IsPathAFolder = (Result = vbDirectory) Or (Result = 1)
   If Result = 16 Then
        PathFolder = True
    Else
        PathFolder = False
    End If
End Function
Public Function DoAddToSendList(text As String)
    frmMain.txtSendBNET.AddItem text, 0
    If frmMain.txtSendBNET.ListCount > 10 Then
        frmMain.txtSendBNET.RemoveItem 10
    Else
    End If
End Function
Public Function ClearBuffers()
    frmMain.rtbChat.text = ""
    frmMain.rtbWhisper.text = ""
    frmMain.txtSendBNET.Clear
End Function
Public Function EncodeBase8(mystring As String) As String
    Dim charSet As String, c As Integer, d As Integer, E As Integer: charSet = "[]<>.,*?"
    For c = 1 To Len(mystring)
    E = Asc(Mid(mystring, c, 1))
        For d = 1 To 3
            EncodeBase8 = EncodeBase8 & Mid(charSet, (E And 7) + 1, 1)
            E = RShift(CDbl(E), 3)
        Next
    Next
End Function
Public Function DecodeBase8(mystring As String) As String
    On Error Resume Next
    Dim d As Integer, i As Integer, c As Integer, charSet As String
    charSet = "[]<>.,*?"
    
    For d = 1 To Len(mystring)
        c = c + (InStr(1, charSet, Mid(mystring, d, 1)) - 1) * (8 ^ i)
        i = i + 1
        If i = 3 Then
            DecodeBase8 = DecodeBase8 & Chr$(c)
            i = 0
            c = 0
        End If
    Next
End Function
Public Function MKL(X As String) As Long
    If Len(X) < 4 Then Exit Function
        CopyMemory MakeLong, ByVal X, 4
End Function
Public Function MKI(X As String) As Integer
    If Len(X) < 2 Then Exit Function
        CopyMemory MakeInt, ByVal X, 2
End Function
Public Function SendBanner()
    With PBuffer
        .InsertNonNTString "68XI" & BNET.Product
        .InsertDWORD 0
        .InsertDWORD GetTickCount
        .SendPacket &H15
    End With
End Function
