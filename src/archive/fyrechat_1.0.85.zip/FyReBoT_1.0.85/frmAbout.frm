VERSION 5.00
Begin VB.Form frmAbout 
   BackColor       =   &H00000000&
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "About FyReBoT"
   ClientHeight    =   2985
   ClientLeft      =   8040
   ClientTop       =   6375
   ClientWidth     =   8670
   ClipControls    =   0   'False
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmAbout.frx":0000
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2060.3
   ScaleMode       =   0  'User
   ScaleWidth      =   8141.577
   StartUpPosition =   2  'CenterScreen
   Begin VB.Label lblVersion 
      BackStyle       =   0  'Transparent
      Caption         =   "v0.0 Build 0"
      ForeColor       =   &H00FFFFFF&
      Height          =   255
      Left            =   7560
      TabIndex        =   3
      Top             =   1920
      Width           =   975
   End
   Begin VB.Label lblCopyright 
      BackStyle       =   0  'Transparent
      Caption         =   "� Fyre Systems, Inc. 2003-2004"
      ForeColor       =   &H00FFFFFF&
      Height          =   255
      Left            =   0
      TabIndex        =   2
      Top             =   1920
      Width           =   2415
   End
   Begin VB.Image Image1 
      Height          =   2115
      Left            =   0
      Picture         =   "frmAbout.frx":C0C2
      Top             =   0
      Width           =   8685
   End
   Begin VB.Label lblURL 
      BackColor       =   &H00000000&
      Caption         =   "http://fyrebot.efyre.com"
      ForeColor       =   &H00FFFFFF&
      Height          =   255
      Left            =   600
      TabIndex        =   1
      Top             =   2400
      Width           =   3015
   End
   Begin VB.Label lblAuthor 
      BackColor       =   &H00000000&
      ForeColor       =   &H00FFFFFF&
      Height          =   855
      Left            =   5400
      TabIndex        =   0
      Top             =   2160
      Width           =   3255
   End
End
Attribute VB_Name = "frmAbout"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Form_Load()
    lblVersion.Caption = "v" & App.Major & "." & App.Minor & " Build " & App.Revision
    lblAuthor.Caption = "Written by: FyRe" & vbCrLf & _
                        " Assistance: Zonker[RC], Raihan[RC]" & vbCrLf & _
                        " Testing: WoLF-Damian[RC], MatrixMan[RC]," & _
                        "                   idiot[RC]" & vbCrLf
End Sub

Private Sub lblURL_Click()
    ShellExecute Me.HWnd, "Open", "http://fyrebot.efyre.com", 0&, 0&, 0&
End Sub
